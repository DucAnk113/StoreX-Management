﻿namespace StoreX_Management
{
    partial class Warehouse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Warehouse));
            lbUser = new Label();
            btnLogout = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtID = new TextBox();
            txtName = new TextBox();
            txtQuantity = new TextBox();
            txtSearch = new TextBox();
            cbCategory = new ComboBox();
            cbSupplier = new ComboBox();
            btnInsert = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnSearch = new Button();
            btnCancel = new Button();
            btnExport = new Button();
            dgvProduct = new DataGridView();
            ProductID = new DataGridViewTextBoxColumn();
            ProductName = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            CategoryID = new DataGridViewTextBoxColumn();
            SupplierID = new DataGridViewTextBoxColumn();
            lblDError = new Label();
            lbNameError = new Label();
            lbQuantityError = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).BeginInit();
            SuspendLayout();
            // 
            // lbUser
            // 
            lbUser.AutoSize = true;
            lbUser.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbUser.Location = new Point(12, 9);
            lbUser.Name = "lbUser";
            lbUser.Size = new Size(64, 25);
            lbUser.TabIndex = 1;
            lbUser.Text = "USER:";
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnLogout.Location = new Point(713, 13);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(75, 23);
            btnLogout.TabIndex = 3;
            btnLogout.Text = "LOGOUT";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.Location = new Point(263, 60);
            label1.Name = "label1";
            label1.Size = new Size(243, 25);
            label1.TabIndex = 4;
            label1.Text = "PRODUCT MANAGEMENT";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label2.Location = new Point(77, 116);
            label2.Name = "label2";
            label2.Size = new Size(20, 15);
            label2.TabIndex = 5;
            label2.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label3.Location = new Point(77, 162);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 6;
            label3.Text = "Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label4.Location = new Point(77, 214);
            label4.Name = "label4";
            label4.Size = new Size(55, 15);
            label4.TabIndex = 7;
            label4.Text = "Quantity";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label5.Location = new Point(437, 116);
            label5.Name = "label5";
            label5.Size = new Size(73, 15);
            label5.TabIndex = 8;
            label5.Text = "Category ID";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label6.Location = new Point(437, 162);
            label6.Name = "label6";
            label6.Size = new Size(69, 15);
            label6.TabIndex = 9;
            label6.Text = "Supplier ID";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label7.Location = new Point(437, 214);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 10;
            label7.Text = "Search";
            // 
            // txtID
            // 
            txtID.Location = new Point(135, 113);
            txtID.Name = "txtID";
            txtID.Size = new Size(210, 23);
            txtID.TabIndex = 11;
            // 
            // txtName
            // 
            txtName.Location = new Point(135, 159);
            txtName.Name = "txtName";
            txtName.Size = new Size(210, 23);
            txtName.TabIndex = 12;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(135, 211);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(210, 23);
            txtQuantity.TabIndex = 13;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(512, 211);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(210, 23);
            txtSearch.TabIndex = 14;
            // 
            // cbCategory
            // 
            cbCategory.FormattingEnabled = true;
            cbCategory.Location = new Point(512, 113);
            cbCategory.Name = "cbCategory";
            cbCategory.Size = new Size(210, 23);
            cbCategory.TabIndex = 15;
            // 
            // cbSupplier
            // 
            cbSupplier.FormattingEnabled = true;
            cbSupplier.Location = new Point(512, 159);
            cbSupplier.Name = "cbSupplier";
            cbSupplier.Size = new Size(210, 23);
            cbSupplier.TabIndex = 16;
            // 
            // btnInsert
            // 
            btnInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnInsert.Location = new Point(77, 258);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(75, 23);
            btnInsert.TabIndex = 17;
            btnInsert.Text = "INSERT";
            btnInsert.UseVisualStyleBackColor = true;
            btnInsert.Click += btnInsert_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnUpdate.Location = new Point(158, 258);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 18;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDelete.Location = new Point(239, 258);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 19;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnSearch
            // 
            btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSearch.Location = new Point(320, 258);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 20;
            btnSearch.Text = "SEARCH";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCancel.Location = new Point(401, 258);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "CANCEL";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnExport
            // 
            btnExport.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnExport.Location = new Point(482, 258);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(75, 23);
            btnExport.TabIndex = 22;
            btnExport.Text = "EXPORT";
            btnExport.UseVisualStyleBackColor = true;
            btnExport.Click += btnExport_Click;
            // 
            // dgvProduct
            // 
            dgvProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProduct.Columns.AddRange(new DataGridViewColumn[] { ProductID, ProductName, Quantity, CategoryID, SupplierID });
            dgvProduct.Location = new Point(12, 288);
            dgvProduct.Name = "dgvProduct";
            dgvProduct.Size = new Size(776, 150);
            dgvProduct.TabIndex = 23;
            dgvProduct.CellClick += dgvProduct_CellClick;
            // 
            // ProductID
            // 
            ProductID.DataPropertyName = "ProductID";
            ProductID.HeaderText = "Product ID";
            ProductID.Name = "ProductID";
            ProductID.Width = 138;
            // 
            // ProductName
            // 
            ProductName.DataPropertyName = "ProductName";
            ProductName.HeaderText = "Name";
            ProductName.Name = "ProductName";
            ProductName.Width = 138;
            // 
            // Quantity
            // 
            Quantity.DataPropertyName = "Quantity";
            Quantity.HeaderText = "Quantity";
            Quantity.Name = "Quantity";
            Quantity.Width = 138;
            // 
            // CategoryID
            // 
            CategoryID.DataPropertyName = "CategoryID";
            CategoryID.HeaderText = "Category ID";
            CategoryID.Name = "CategoryID";
            CategoryID.Width = 138;
            // 
            // SupplierID
            // 
            SupplierID.DataPropertyName = "SupplierID";
            SupplierID.HeaderText = "Supplier ID";
            SupplierID.Name = "SupplierID";
            SupplierID.Width = 138;
            // 
            // lblDError
            // 
            lblDError.AutoSize = true;
            lblDError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblDError.ForeColor = Color.Red;
            lblDError.Location = new Point(135, 139);
            lblDError.Name = "lblDError";
            lblDError.Size = new Size(0, 15);
            lblDError.TabIndex = 24;
            // 
            // lbNameError
            // 
            lbNameError.AutoSize = true;
            lbNameError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNameError.ForeColor = Color.Red;
            lbNameError.Location = new Point(135, 185);
            lbNameError.Name = "lbNameError";
            lbNameError.Size = new Size(0, 15);
            lbNameError.TabIndex = 25;
            // 
            // lbQuantityError
            // 
            lbQuantityError.AutoSize = true;
            lbQuantityError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbQuantityError.ForeColor = Color.Red;
            lbQuantityError.Location = new Point(135, 237);
            lbQuantityError.Name = "lbQuantityError";
            lbQuantityError.Size = new Size(0, 15);
            lbQuantityError.TabIndex = 26;
            // 
            // Warehouse
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(lbQuantityError);
            Controls.Add(lbNameError);
            Controls.Add(lblDError);
            Controls.Add(dgvProduct);
            Controls.Add(btnExport);
            Controls.Add(btnCancel);
            Controls.Add(btnSearch);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnInsert);
            Controls.Add(cbSupplier);
            Controls.Add(cbCategory);
            Controls.Add(txtSearch);
            Controls.Add(txtQuantity);
            Controls.Add(txtName);
            Controls.Add(txtID);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnLogout);
            Controls.Add(lbUser);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Warehouse";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Warehouse";
            Load += Warehouse_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProduct).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbUser;
        private Button btnLogout;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtID;
        private TextBox txtName;
        private TextBox txtQuantity;
        private TextBox txtSearch;
        private ComboBox cbCategory;
        private ComboBox cbSupplier;
        private Button btnInsert;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnSearch;
        private Button btnCancel;
        private Button btnExport;
        private DataGridView dgvProduct;
        private DataGridViewTextBoxColumn ProductID;
        private DataGridViewTextBoxColumn ProductName;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn CategoryID;
        private DataGridViewTextBoxColumn SupplierID;
        private Label lblDError;
        private Label lbNameError;
        private Label lbQuantityError;
    }
}