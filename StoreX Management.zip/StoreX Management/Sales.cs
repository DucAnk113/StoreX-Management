﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StoreX_Management
{
    public partial class Sales : Form
    {
        SqlConnection connection;
        public Sales(string username)
        {
            InitializeComponent();
            connection = new SqlConnection("Server=DucAnk;Database=StoreX;Integrated Security=true;TrustServerCertificate=True;");
            lbUser.Text = "USER: " + username;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login loginForm = new Login();
            loginForm.ShowDialog();
            this.Dispose();
        }

        private void Sales_Load(object sender, EventArgs e)
        {
            connection.Open();
            GetCategory();
            GetSupplier();
            FillData(); // Product management
            LoadCustomers(); // Customer management
            FillOrderData(); // Order management
        }

        public void FillData()
        {
            string query = "SELECT * FROM Products";
            DataTable tbl = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(query, connection);
            ad.Fill(tbl);
            dgvProduct.DataSource = tbl;
            connection.Close();
        }

        public void GetCategory()
        {
            string query = "select CategoryID, CategoryName from Categories";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
            cbCategory.DataSource = table;
            cbCategory.DisplayMember = "CategoryName";
            cbCategory.ValueMember = "CategoryID";
        }

        public void GetSupplier()
        {
            string query = "select SupplierID, SupplierName from Suppliers";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
            cbSupplier.DataSource = table;
            cbSupplier.DisplayMember = "SupplierName";
            cbSupplier.ValueMember = "SupplierID";
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            int error = 0;
            string id = txtID.Text;
            if (id.Equals(""))
            {
                error = error + 1;
                lblDError.Text = "ID can't be blank";
            }
            else
                lblDError.Text = "";
            string name = txtName.Text;
            if (name.Equals(""))
            {
                error = error + 1;
                lbNameError.Text = "Name can't be blank";
            }
            else
                lbNameError.Text = "";
            string quantity = txtQuantity.Text;
            if (quantity.Equals(""))
            {
                error = error + 1;
                lbQuantityError.Text = "Quantity can't be blank";
            }
            else
            {
                string query = "select * from Products where ProductID = @id";
                connection.Open();
                SqlCommand cmdcheck = new SqlCommand(query, connection);
                cmdcheck.Parameters.Add("@id", SqlDbType.Int);
                cmdcheck.Parameters["@id"].Value = id;
                SqlDataReader reader = cmdcheck.ExecuteReader();
                if (reader.Read())
                {
                    error++;
                    lblDError.Text = "This ID is existing, please choose another";
                }
                else
                {
                    lbQuantityError.Text = "";
                }
                connection.Close();
            }
            string catid = cbCategory.SelectedValue.ToString();
            string supid = cbSupplier.SelectedValue.ToString();

            if (error == 0)
            {
                connection.Open();
                SqlCommand cmdSetOn = new SqlCommand("SET IDENTITY_INSERT Products ON", connection);
                cmdSetOn.ExecuteNonQuery();
                string insert = "INSERT INTO Products (ProductID, ProductName, Quantity, CategoryID, SupplierID) " +
                                "VALUES (@id, @name, @quantity, @catid, @supid)";
                SqlCommand cmd = new SqlCommand(insert, connection);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = id;
                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = name;
                cmd.Parameters.Add("@quantity", SqlDbType.Int);
                cmd.Parameters["@quantity"].Value = quantity;
                cmd.Parameters.Add("@catid", SqlDbType.Int);
                cmd.Parameters["@catid"].Value = catid;
                cmd.Parameters.Add("@supid", SqlDbType.Int);
                cmd.Parameters["@supid"].Value = supid;
                cmd.ExecuteNonQuery();
                SqlCommand cmdSetOff = new SqlCommand("SET IDENTITY_INSERT Products OFF", connection);
                cmdSetOff.ExecuteNonQuery();
                connection.Close();
                FillData();
                MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
            txtQuantity.Text = "";
            cbCategory.Text = "";
            cbSupplier.Text = "";
            lblDError.Text = "";
            lbNameError.Text = "";
            lbQuantityError.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show(this, "Do you want to edit?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                string update = "update Products set ProductName =@name, Quantity = @quantity, CategoryID=@catid, SupplierID=@supid"
               + " where ProductID = @productid";
                connection.Open();
                SqlCommand cmd = new SqlCommand(update, connection);
                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;
                cmd.Parameters.Add("@quantity", SqlDbType.Int);
                cmd.Parameters["@quantity"].Value = txtQuantity.Text;
                cmd.Parameters.Add("@catid", SqlDbType.Int);
                cmd.Parameters["@catid"].Value = int.Parse(cbCategory.SelectedValue.ToString());
                cmd.Parameters.Add("@supid", SqlDbType.Int);
                cmd.Parameters["@supid"].Value = int.Parse(cbSupplier.SelectedValue.ToString());
                cmd.Parameters.Add("@productid", SqlDbType.Int);
                cmd.Parameters["@productid"].Value = txtID.Text;
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    FillData();
                    MessageBox.Show(this, "Updated successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(this, "Update failed", "Result", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                connection.Close();
            }
        }

        private void dgvProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvProduct.Rows[e.RowIndex];
                txtID.Text = row.Cells["ProductID"].Value.ToString();
                txtName.Text = row.Cells["ProductName"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
                cbSupplier.SelectedValue = row.Cells["SupplierID"].Value.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show(this, "Do you want to delete?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                connection.Open();
                string delete = "delete from Products where ProductID = @productid";
                SqlCommand cmd = new SqlCommand(delete, connection);
                cmd.Parameters.Add("@productid", SqlDbType.Int);
                cmd.Parameters["@productid"].Value = txtID.Text;
                cmd.ExecuteNonQuery();
                FillData();
                MessageBox.Show(this, "Deleted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword.Equals(""))
            {
                MessageBox.Show(this, "Please enter a product name to search", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "SELECT * FROM Products WHERE ProductName LIKE @keyword";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@keyword", SqlDbType.VarChar);
                cmd.Parameters["@keyword"].Value = "%" + keyword + "%";
                DataTable tbl = new DataTable();
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                ad.Fill(tbl);
                dgvProduct.DataSource = tbl;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        // Customer management
        public void LoadCustomers()
        {
            FillCustomerData();
        }

        public void FillCustomerData()
        {
            const string query = "SELECT * FROM Customers";
            var tbl = new DataTable();
            using (var da = new SqlDataAdapter(query, connection))
                da.Fill(tbl);

            dgvCustomer.DataSource = tbl;
            connection.Close();
        }

        private void ClearCustomerFields()
        {
            txtCustID.Text = "";
            txtCustName.Text = "";
            txtCustEmail.Text = "";
            txtCustPhone.Text = "";
            txtCustAddress.Text = "";
            txtCustSearch.Text = "";
            dgvOrderHistory.DataSource = null;
        }

        private void LoadOrderHistory(int customerId)
        {
            const string query = @"
        SELECT OrderID, OrderDate, TotalAmount
          FROM Orders
         WHERE CustomerID = @cid";
            var tbl = new DataTable();
            using (var cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@cid", customerId);
                using (var da = new SqlDataAdapter(cmd))
                    da.Fill(tbl);
            }
            dgvOrderHistory.DataSource = tbl;
        }

        private void btnCustInsert_Click(object sender, EventArgs e)
        {
            int error = 0;
            string name = txtCustName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                error++;
                MessageBox.Show(this, "Name is required", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            string phone = txtCustPhone.Text.Trim();
            string addr = txtCustAddress.Text.Trim();
            string email = txtCustEmail.Text.Trim();

            if (error == 0)
            {
                try
                {
                    connection.Open();
                    const string insert = @"
                        INSERT INTO Customers
                            (CustomerName, PhoneNumber, Address, Email)
                        VALUES
                            (@name, @phone, @addr, @email)";
                    using (var cmd = new SqlCommand(insert, connection))
                    {
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@phone", phone);
                        cmd.Parameters.AddWithValue("@addr", addr);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.ExecuteNonQuery();
                    }
                    FillCustomerData();
                    MessageBox.Show(this, "Customer added", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void btnCustUpdate_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtCustID.Text, out var id)) return;
            if (MessageBox.Show("Save changes?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;

            try
            {
                connection.Open();
                const string update = @"
            UPDATE Customers
               SET CustomerName = @name,
                   PhoneNumber  = @phone,
                   Address      = @addr,
                   Email        = @email
             WHERE CustomerID  = @id";
                using (var cmd = new SqlCommand(update, connection))
                {
                    cmd.Parameters.AddWithValue("@name", txtCustName.Text.Trim());
                    cmd.Parameters.AddWithValue("@phone", txtCustPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@addr", txtCustAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", txtCustEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", id);
                    var rows = cmd.ExecuteNonQuery();
                    MessageBox.Show(
                        rows > 0 ? "Updated successfully" : "No record updated",
                        "Result",
                        MessageBoxButtons.OK,
                        rows > 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning
                    );
                }
                ClearCustomerFields();
                FillCustomerData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnCustDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtCustID.Text, out var id)) return;
            if (MessageBox.Show("Delete this customer?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;

            try
            {
                connection.Open();
                const string delete = "DELETE FROM Customers WHERE CustomerID = @id";
                using (var cmd = new SqlCommand(delete, connection))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Deleted", "Result",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearCustomerFields();
                FillCustomerData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnCustSearch_Click(object sender, EventArgs e)
        {
            var kw = txtCustSearch.Text.Trim();
            if (kw == "")
            {
                MessageBox.Show("Enter name to search", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                connection.Open();
                const string query = @"
            SELECT * 
              FROM Customers 
             WHERE CustomerName LIKE @kw";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@kw", "%" + kw + "%");
                    var tbl = new DataTable();
                    using (var da = new SqlDataAdapter(cmd))
                        da.Fill(tbl);
                    dgvCustomer.DataSource = tbl;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void dgvCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvCustomer.Rows[e.RowIndex];
            txtCustID.Text = row.Cells["CustomerID"].Value.ToString();
            txtCustName.Text = row.Cells["CustomerName"].Value.ToString();
            txtCustPhone.Text = row.Cells["PhoneNumber"].Value.ToString();
            txtCustAddress.Text = row.Cells["Address"].Value.ToString();
            txtCustEmail.Text = row.Cells["Email"].Value.ToString();

            if (int.TryParse(txtCustID.Text, out var cid))
                LoadOrderHistory(cid);
        }

        //Order management
        public void FillOrderData()
        {
            string query = "SELECT o.OrderID, o.CustomerID, c.CustomerName, o.OrderDate, o.TotalAmount " +
                           "FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID";
            DataTable tbl = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(query, connection);
            ad.Fill(tbl);
            connection.Close();
        }

        private void btnSubmitOrder_Click(object sender, EventArgs e)
        {
            // Giả sử bạn có một biến 'loggedInUserId' chứa ID của người dùng đã đăng nhập.
            // Bạn cần khởi tạo biến này sau khi người dùng đăng nhập thành công.
            int loggedInUserId = GetCurrentUserId(); // Đây là hàm ví dụ để lấy UserID

            if (!int.TryParse(txtOrderCustomer.Text.Trim(), out int customerId))
            {
                MessageBox.Show("Please enter a valid Customer ID", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DateTime orderDate = dtpOrderDate.Value;

            if (!decimal.TryParse(txtOrderAmount.Text.Trim(), out decimal totalAmount))
            {
                MessageBox.Show("Please enter a valid total amount", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                connection.Open();
                string insertOrderQuery = "INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, UserID) VALUES (@cid, @date, @amt, @UserID)";
                using (SqlCommand cmd = new SqlCommand(insertOrderQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@cid", customerId);
                    cmd.Parameters.AddWithValue("@date", orderDate);
                    cmd.Parameters.AddWithValue("@amt", totalAmount);
                    cmd.Parameters.AddWithValue("@UserID", loggedInUserId);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Order has been made successfully.", "Order Made", MessageBoxButtons.OK, MessageBoxIcon.Information);

                FillOrderData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error making the order: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private int GetCurrentUserId()
        {
            // Logic để lấy ID của người dùng đang đăng nhập.
            // Ví dụ, bạn có thể lưu nó trong một biến toàn cục hoặc một lớp tĩnh sau khi đăng nhập.
            // Ở đây tôi sẽ trả về một giá trị giả định.
            return 1; // Giả sử ID của người dùng 'sales' là 1
        }

        public void GetOrderStatsByCustomer(DataGridView grid)
        {
            string query = "SELECT c.CustomerName, COUNT(o.OrderID) AS TotalOrders, SUM(o.TotalAmount) AS TotalSpent " +
                           "FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID " +
                           "GROUP BY c.CustomerName ORDER BY TotalSpent DESC";
            DataTable tbl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, connection);
            da.Fill(tbl);
            grid.DataSource = tbl;
        }

        public void GetOrderStatsByDateRange(DateTime fromDate, DateTime toDate, DataGridView grid)
        {
            string query = "SELECT OrderID, CustomerID, OrderDate, TotalAmount FROM Orders " +
                           "WHERE OrderDate BETWEEN @from AND @to ORDER BY OrderDate";
            DataTable tbl = new DataTable();
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@from", fromDate);
            cmd.Parameters.AddWithValue("@to", toDate);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(tbl);
            grid.DataSource = tbl;
        }

        private void btnStatsCustomer_Click(object sender, EventArgs e)
        {
            GetOrderStatsByCustomer(dgvStats);
        }

        private void btnStatsDateRange_Click(object sender, EventArgs e)
        {
            DateTime from = dtpFromDate.Value.Date;
            DateTime to = dtpToDate.Value.Date;
            GetOrderStatsByDateRange(from, to, dgvStats);
        }

        private void btnCustCancel_Click(object sender, EventArgs e)
        {
            txtCustID.Text = "";
            txtCustName.Text = "";
            txtCustPhone.Text = "";
            txtCustAddress.Text = "";
            txtCustEmail.Text = "";
        }
    }
}
