﻿namespace StoreX_Management
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            lbUser = new Label();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            btnEmpCancel = new Button();
            btnEmpSearch = new Button();
            btnEmpDelete = new Button();
            btnEmpUpdate = new Button();
            btnEmpInsert = new Button();
            dgvEmployee = new DataGridView();
            EmployeeID = new DataGridViewTextBoxColumn();
            EmployeeName = new DataGridViewTextBoxColumn();
            Position = new DataGridViewTextBoxColumn();
            AuthorityLevel = new DataGridViewTextBoxColumn();
            Department = new DataGridViewTextBoxColumn();
            txtEmpSearch = new TextBox();
            label17 = new Label();
            label16 = new Label();
            txtDepartment = new TextBox();
            txtAuthorityLevel = new TextBox();
            txtPosition = new TextBox();
            txtEmpName = new TextBox();
            txtEmpID = new TextBox();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            tabPage2 = new TabPage();
            label9 = new Label();
            dgvOrderHistory = new DataGridView();
            dgvCustomer = new DataGridView();
            CustomerID = new DataGridViewTextBoxColumn();
            CustomerName = new DataGridViewTextBoxColumn();
            PhoneNumber = new DataGridViewTextBoxColumn();
            Address = new DataGridViewTextBoxColumn();
            Email = new DataGridViewTextBoxColumn();
            label8 = new Label();
            btnCustSearch = new Button();
            btnCustDelete = new Button();
            btnCustUpdate = new Button();
            btnCustInsert = new Button();
            label7 = new Label();
            txtCustSearch = new TextBox();
            txtCustEmail = new TextBox();
            txtCustAddress = new TextBox();
            txtCustPhone = new TextBox();
            txtCustName = new TextBox();
            txtCustID = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tabPage3 = new TabPage();
            lbQuantityError = new Label();
            lbNameError = new Label();
            lblDError = new Label();
            dgvProduct = new DataGridView();
            ProductID = new DataGridViewTextBoxColumn();
            ProductName = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            CategoryID = new DataGridViewTextBoxColumn();
            SupplierID = new DataGridViewTextBoxColumn();
            btnCancel = new Button();
            btnSearch = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            cbSupplier = new ComboBox();
            cbCategory = new ComboBox();
            txtSearch = new TextBox();
            txtQuantity = new TextBox();
            txtName = new TextBox();
            txtID = new TextBox();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            tabPage4 = new TabPage();
            txtUserID = new TextBox();
            label31 = new Label();
            dtpOrderDate = new DateTimePicker();
            btnOrderCancel = new Button();
            btnOrderSearch = new Button();
            btnOrderDelete = new Button();
            btnOrderUpdate = new Button();
            btnOrderInsert = new Button();
            dgvOrder = new DataGridView();
            OrderID = new DataGridViewTextBoxColumn();
            OrderDate = new DataGridViewTextBoxColumn();
            CustomerIDColumn = new DataGridViewTextBoxColumn();
            TotalAmount = new DataGridViewTextBoxColumn();
            label36 = new Label();
            label35 = new Label();
            txtOrderSearch = new TextBox();
            txtTotalAmount = new TextBox();
            txtOrderCustomerID = new TextBox();
            txtOrderID = new TextBox();
            label30 = new Label();
            label32 = new Label();
            label33 = new Label();
            label34 = new Label();
            label29 = new Label();
            tabPage5 = new TabPage();
            btnStatsEmployee = new Button();
            dtpToDate = new DateTimePicker();
            dtpFromDate = new DateTimePicker();
            label25 = new Label();
            label26 = new Label();
            btnStatsDateRange = new Button();
            btnStatsCustomer = new Button();
            label27 = new Label();
            dgvStats = new DataGridView();
            label28 = new Label();
            btnLogout = new Button();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEmployee).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrderHistory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomer).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).BeginInit();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrder).BeginInit();
            tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStats).BeginInit();
            SuspendLayout();
            // 
            // lbUser
            // 
            lbUser.AutoSize = true;
            lbUser.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbUser.Location = new Point(12, 9);
            lbUser.Name = "lbUser";
            lbUser.Size = new Size(64, 25);
            lbUser.TabIndex = 0;
            lbUser.Text = "USER:";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Location = new Point(12, 37);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(776, 401);
            tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnEmpCancel);
            tabPage1.Controls.Add(btnEmpSearch);
            tabPage1.Controls.Add(btnEmpDelete);
            tabPage1.Controls.Add(btnEmpUpdate);
            tabPage1.Controls.Add(btnEmpInsert);
            tabPage1.Controls.Add(dgvEmployee);
            tabPage1.Controls.Add(txtEmpSearch);
            tabPage1.Controls.Add(label17);
            tabPage1.Controls.Add(label16);
            tabPage1.Controls.Add(txtDepartment);
            tabPage1.Controls.Add(txtAuthorityLevel);
            tabPage1.Controls.Add(txtPosition);
            tabPage1.Controls.Add(txtEmpName);
            tabPage1.Controls.Add(txtEmpID);
            tabPage1.Controls.Add(label15);
            tabPage1.Controls.Add(label14);
            tabPage1.Controls.Add(label13);
            tabPage1.Controls.Add(label12);
            tabPage1.Controls.Add(label11);
            tabPage1.Controls.Add(label10);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(768, 373);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Manager Employee";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnEmpCancel
            // 
            btnEmpCancel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnEmpCancel.Location = new Point(641, 324);
            btnEmpCancel.Name = "btnEmpCancel";
            btnEmpCancel.Size = new Size(75, 23);
            btnEmpCancel.TabIndex = 49;
            btnEmpCancel.Text = "CANCEL";
            btnEmpCancel.UseVisualStyleBackColor = true;
            btnEmpCancel.Click += btnEmpCancel_Click;
            // 
            // btnEmpSearch
            // 
            btnEmpSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnEmpSearch.Location = new Point(560, 324);
            btnEmpSearch.Name = "btnEmpSearch";
            btnEmpSearch.Size = new Size(75, 23);
            btnEmpSearch.TabIndex = 48;
            btnEmpSearch.Text = "SEARCH";
            btnEmpSearch.UseVisualStyleBackColor = true;
            btnEmpSearch.Click += btnEmpSearch_Click;
            // 
            // btnEmpDelete
            // 
            btnEmpDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnEmpDelete.Location = new Point(479, 324);
            btnEmpDelete.Name = "btnEmpDelete";
            btnEmpDelete.Size = new Size(75, 23);
            btnEmpDelete.TabIndex = 47;
            btnEmpDelete.Text = "DELETE";
            btnEmpDelete.UseVisualStyleBackColor = true;
            btnEmpDelete.Click += btnEmpDelete_Click;
            // 
            // btnEmpUpdate
            // 
            btnEmpUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnEmpUpdate.Location = new Point(398, 324);
            btnEmpUpdate.Name = "btnEmpUpdate";
            btnEmpUpdate.Size = new Size(75, 23);
            btnEmpUpdate.TabIndex = 46;
            btnEmpUpdate.Text = "UPDATE";
            btnEmpUpdate.UseVisualStyleBackColor = true;
            btnEmpUpdate.Click += btnEmpUpdate_Click;
            // 
            // btnEmpInsert
            // 
            btnEmpInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnEmpInsert.Location = new Point(317, 324);
            btnEmpInsert.Name = "btnEmpInsert";
            btnEmpInsert.Size = new Size(75, 23);
            btnEmpInsert.TabIndex = 45;
            btnEmpInsert.Text = "INSERT";
            btnEmpInsert.UseVisualStyleBackColor = true;
            btnEmpInsert.Click += btnEmpInsert_Click;
            // 
            // dgvEmployee
            // 
            dgvEmployee.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmployee.Columns.AddRange(new DataGridViewColumn[] { EmployeeID, EmployeeName, Position, AuthorityLevel, Department });
            dgvEmployee.Location = new Point(317, 100);
            dgvEmployee.Name = "dgvEmployee";
            dgvEmployee.Size = new Size(445, 205);
            dgvEmployee.TabIndex = 44;
            dgvEmployee.CellClick += dgvEmployee_CellClick;
            // 
            // EmployeeID
            // 
            EmployeeID.DataPropertyName = "EmployeeID";
            EmployeeID.HeaderText = "Employee ID";
            EmployeeID.Name = "EmployeeID";
            // 
            // EmployeeName
            // 
            EmployeeName.DataPropertyName = "EmployeeName";
            EmployeeName.HeaderText = "Name";
            EmployeeName.Name = "EmployeeName";
            // 
            // Position
            // 
            Position.DataPropertyName = "Position";
            Position.HeaderText = "Position";
            Position.Name = "Position";
            // 
            // AuthorityLevel
            // 
            AuthorityLevel.DataPropertyName = "AuthorityLevel";
            AuthorityLevel.HeaderText = "Authority";
            AuthorityLevel.Name = "AuthorityLevel";
            // 
            // Department
            // 
            Department.DataPropertyName = "Department";
            Department.HeaderText = "Department";
            Department.Name = "Department";
            // 
            // txtEmpSearch
            // 
            txtEmpSearch.Location = new Point(539, 70);
            txtEmpSearch.Name = "txtEmpSearch";
            txtEmpSearch.Size = new Size(188, 23);
            txtEmpSearch.TabIndex = 43;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label17.Location = new Point(438, 73);
            label17.Name = "label17";
            label17.Size = new Size(95, 15);
            label17.TabIndex = 42;
            label17.Text = "Search by name";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label16.Location = new Point(486, 15);
            label16.Name = "label16";
            label16.Size = new Size(159, 25);
            label16.TabIndex = 41;
            label16.Text = "List Of Employee";
            // 
            // txtDepartment
            // 
            txtDepartment.Location = new Point(107, 287);
            txtDepartment.Name = "txtDepartment";
            txtDepartment.Size = new Size(183, 23);
            txtDepartment.TabIndex = 10;
            // 
            // txtAuthorityLevel
            // 
            txtAuthorityLevel.Location = new Point(107, 227);
            txtAuthorityLevel.Name = "txtAuthorityLevel";
            txtAuthorityLevel.Size = new Size(183, 23);
            txtAuthorityLevel.TabIndex = 9;
            // 
            // txtPosition
            // 
            txtPosition.Location = new Point(107, 170);
            txtPosition.Name = "txtPosition";
            txtPosition.Size = new Size(183, 23);
            txtPosition.TabIndex = 8;
            // 
            // txtEmpName
            // 
            txtEmpName.Location = new Point(107, 118);
            txtEmpName.Name = "txtEmpName";
            txtEmpName.Size = new Size(183, 23);
            txtEmpName.TabIndex = 7;
            // 
            // txtEmpID
            // 
            txtEmpID.Location = new Point(107, 70);
            txtEmpID.Name = "txtEmpID";
            txtEmpID.Size = new Size(183, 23);
            txtEmpID.TabIndex = 6;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label15.Location = new Point(16, 290);
            label15.Name = "label15";
            label15.Size = new Size(76, 15);
            label15.TabIndex = 5;
            label15.Text = "Department";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label14.Location = new Point(16, 230);
            label14.Name = "label14";
            label14.Size = new Size(60, 15);
            label14.TabIndex = 4;
            label14.Text = "Authority";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label13.Location = new Point(16, 173);
            label13.Name = "label13";
            label13.Size = new Size(51, 15);
            label13.TabIndex = 3;
            label13.Text = "Position";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label12.Location = new Point(16, 121);
            label12.Name = "label12";
            label12.Size = new Size(40, 15);
            label12.TabIndex = 2;
            label12.Text = "Name";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label11.Location = new Point(16, 73);
            label11.Name = "label11";
            label11.Size = new Size(20, 15);
            label11.TabIndex = 1;
            label11.Text = "ID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label10.Location = new Point(27, 15);
            label10.Name = "label10";
            label10.Size = new Size(221, 25);
            label10.TabIndex = 0;
            label10.Text = "Employee Management";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(dgvOrderHistory);
            tabPage2.Controls.Add(dgvCustomer);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(btnCustSearch);
            tabPage2.Controls.Add(btnCustDelete);
            tabPage2.Controls.Add(btnCustUpdate);
            tabPage2.Controls.Add(btnCustInsert);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(txtCustSearch);
            tabPage2.Controls.Add(txtCustEmail);
            tabPage2.Controls.Add(txtCustAddress);
            tabPage2.Controls.Add(txtCustPhone);
            tabPage2.Controls.Add(txtCustName);
            tabPage2.Controls.Add(txtCustID);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(label2);
            tabPage2.Controls.Add(label1);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(768, 373);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Manager Customer";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label9.Location = new Point(421, 217);
            label9.Name = "label9";
            label9.Size = new Size(239, 25);
            label9.TabIndex = 43;
            label9.Text = "Customer's Order History";
            // 
            // dgvOrderHistory
            // 
            dgvOrderHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrderHistory.Location = new Point(293, 245);
            dgvOrderHistory.Name = "dgvOrderHistory";
            dgvOrderHistory.Size = new Size(463, 110);
            dgvOrderHistory.TabIndex = 42;
            // 
            // dgvCustomer
            // 
            dgvCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomer.Columns.AddRange(new DataGridViewColumn[] { CustomerID, CustomerName, PhoneNumber, Address, Email });
            dgvCustomer.Location = new Point(293, 74);
            dgvCustomer.Name = "dgvCustomer";
            dgvCustomer.Size = new Size(463, 121);
            dgvCustomer.TabIndex = 41;
            dgvCustomer.CellClick += dgvCustomer_CellClick;
            // 
            // CustomerID
            // 
            CustomerID.DataPropertyName = "CustomerID";
            CustomerID.HeaderText = "Customer ID";
            CustomerID.Name = "CustomerID";
            // 
            // CustomerName
            // 
            CustomerName.DataPropertyName = "CustomerName";
            CustomerName.HeaderText = "Name";
            CustomerName.Name = "CustomerName";
            // 
            // PhoneNumber
            // 
            PhoneNumber.DataPropertyName = "PhoneNumber";
            PhoneNumber.HeaderText = "Number";
            PhoneNumber.Name = "PhoneNumber";
            // 
            // Address
            // 
            Address.DataPropertyName = "Address";
            Address.HeaderText = "Address";
            Address.Name = "Address";
            // 
            // Email
            // 
            Email.DataPropertyName = "Email";
            Email.HeaderText = "Email";
            Email.Name = "Email";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label8.Location = new Point(460, 17);
            label8.Name = "label8";
            label8.Size = new Size(159, 25);
            label8.TabIndex = 40;
            label8.Text = "List Of Customer";
            // 
            // btnCustSearch
            // 
            btnCustSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustSearch.Location = new Point(93, 332);
            btnCustSearch.Name = "btnCustSearch";
            btnCustSearch.Size = new Size(75, 23);
            btnCustSearch.TabIndex = 39;
            btnCustSearch.Text = "SEARCH";
            btnCustSearch.UseVisualStyleBackColor = true;
            btnCustSearch.Click += btnCustSearch_Click;
            // 
            // btnCustDelete
            // 
            btnCustDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustDelete.Location = new Point(12, 332);
            btnCustDelete.Name = "btnCustDelete";
            btnCustDelete.Size = new Size(75, 23);
            btnCustDelete.TabIndex = 38;
            btnCustDelete.Text = "DELETE";
            btnCustDelete.UseVisualStyleBackColor = true;
            btnCustDelete.Click += btnCustDelete_Click;
            // 
            // btnCustUpdate
            // 
            btnCustUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustUpdate.Location = new Point(93, 303);
            btnCustUpdate.Name = "btnCustUpdate";
            btnCustUpdate.Size = new Size(75, 23);
            btnCustUpdate.TabIndex = 37;
            btnCustUpdate.Text = "UPDATE";
            btnCustUpdate.UseVisualStyleBackColor = true;
            btnCustUpdate.Click += btnCustUpdate_Click;
            // 
            // btnCustInsert
            // 
            btnCustInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustInsert.Location = new Point(12, 303);
            btnCustInsert.Name = "btnCustInsert";
            btnCustInsert.Size = new Size(75, 23);
            btnCustInsert.TabIndex = 36;
            btnCustInsert.Text = "INSERT";
            btnCustInsert.UseVisualStyleBackColor = true;
            btnCustInsert.Click += btnCustInsert_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label7.Location = new Point(293, 48);
            label7.Name = "label7";
            label7.Size = new Size(95, 15);
            label7.TabIndex = 35;
            label7.Text = "Search by name";
            // 
            // txtCustSearch
            // 
            txtCustSearch.Location = new Point(394, 45);
            txtCustSearch.Name = "txtCustSearch";
            txtCustSearch.Size = new Size(188, 23);
            txtCustSearch.TabIndex = 34;
            // 
            // txtCustEmail
            // 
            txtCustEmail.Location = new Point(79, 274);
            txtCustEmail.Name = "txtCustEmail";
            txtCustEmail.Size = new Size(188, 23);
            txtCustEmail.TabIndex = 33;
            // 
            // txtCustAddress
            // 
            txtCustAddress.Location = new Point(79, 224);
            txtCustAddress.Name = "txtCustAddress";
            txtCustAddress.Size = new Size(188, 23);
            txtCustAddress.TabIndex = 32;
            // 
            // txtCustPhone
            // 
            txtCustPhone.Location = new Point(79, 172);
            txtCustPhone.Name = "txtCustPhone";
            txtCustPhone.Size = new Size(188, 23);
            txtCustPhone.TabIndex = 31;
            // 
            // txtCustName
            // 
            txtCustName.Location = new Point(79, 127);
            txtCustName.Name = "txtCustName";
            txtCustName.Size = new Size(188, 23);
            txtCustName.TabIndex = 30;
            // 
            // txtCustID
            // 
            txtCustID.Location = new Point(79, 79);
            txtCustID.Name = "txtCustID";
            txtCustID.Size = new Size(188, 23);
            txtCustID.TabIndex = 29;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(16, 277);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 28;
            label6.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(16, 227);
            label5.Name = "label5";
            label5.Size = new Size(51, 15);
            label5.TabIndex = 27;
            label5.Text = "Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(16, 175);
            label4.Name = "label4";
            label4.Size = new Size(53, 15);
            label4.TabIndex = 26;
            label4.Text = "Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(16, 130);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 25;
            label3.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(16, 82);
            label2.Name = "label2";
            label2.Size = new Size(20, 15);
            label2.TabIndex = 24;
            label2.Text = "ID";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.Location = new Point(31, 17);
            label1.Name = "label1";
            label1.Size = new Size(255, 25);
            label1.TabIndex = 23;
            label1.Text = "CUSTOMER MANAGEMENT";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(lbQuantityError);
            tabPage3.Controls.Add(lbNameError);
            tabPage3.Controls.Add(lblDError);
            tabPage3.Controls.Add(dgvProduct);
            tabPage3.Controls.Add(btnCancel);
            tabPage3.Controls.Add(btnSearch);
            tabPage3.Controls.Add(btnDelete);
            tabPage3.Controls.Add(btnUpdate);
            tabPage3.Controls.Add(btnInsert);
            tabPage3.Controls.Add(cbSupplier);
            tabPage3.Controls.Add(cbCategory);
            tabPage3.Controls.Add(txtSearch);
            tabPage3.Controls.Add(txtQuantity);
            tabPage3.Controls.Add(txtName);
            tabPage3.Controls.Add(txtID);
            tabPage3.Controls.Add(label18);
            tabPage3.Controls.Add(label19);
            tabPage3.Controls.Add(label20);
            tabPage3.Controls.Add(label21);
            tabPage3.Controls.Add(label22);
            tabPage3.Controls.Add(label23);
            tabPage3.Controls.Add(label24);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(768, 373);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Manager Product";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // lbQuantityError
            // 
            lbQuantityError.AutoSize = true;
            lbQuantityError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbQuantityError.ForeColor = Color.Red;
            lbQuantityError.Location = new Point(119, 175);
            lbQuantityError.Name = "lbQuantityError";
            lbQuantityError.Size = new Size(0, 15);
            lbQuantityError.TabIndex = 71;
            // 
            // lbNameError
            // 
            lbNameError.AutoSize = true;
            lbNameError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNameError.ForeColor = Color.Red;
            lbNameError.Location = new Point(119, 123);
            lbNameError.Name = "lbNameError";
            lbNameError.Size = new Size(0, 15);
            lbNameError.TabIndex = 70;
            // 
            // lblDError
            // 
            lblDError.AutoSize = true;
            lblDError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblDError.ForeColor = Color.Red;
            lblDError.Location = new Point(119, 77);
            lblDError.Name = "lblDError";
            lblDError.Size = new Size(0, 15);
            lblDError.TabIndex = 69;
            // 
            // dgvProduct
            // 
            dgvProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProduct.Columns.AddRange(new DataGridViewColumn[] { ProductID, ProductName, Quantity, CategoryID, SupplierID });
            dgvProduct.Location = new Point(6, 226);
            dgvProduct.Name = "dgvProduct";
            dgvProduct.Size = new Size(756, 142);
            dgvProduct.TabIndex = 68;
            dgvProduct.CellClick += dgvProduct_CellClick;
            dgvProduct.CellContentClick += dgvProduct_CellContentClick;
            // 
            // ProductID
            // 
            ProductID.DataPropertyName = "ProductID";
            ProductID.HeaderText = "Product ID";
            ProductID.Name = "ProductID";
            ProductID.Width = 138;
            // 
            // ProductName
            // 
            ProductName.DataPropertyName = "ProductName";
            ProductName.HeaderText = "Name";
            ProductName.Name = "ProductName";
            ProductName.Width = 138;
            // 
            // Quantity
            // 
            Quantity.DataPropertyName = "Quantity";
            Quantity.HeaderText = "Quantity";
            Quantity.Name = "Quantity";
            Quantity.Width = 138;
            // 
            // CategoryID
            // 
            CategoryID.DataPropertyName = "CategoryID";
            CategoryID.HeaderText = "Category ID";
            CategoryID.Name = "CategoryID";
            CategoryID.Width = 138;
            // 
            // SupplierID
            // 
            SupplierID.DataPropertyName = "SupplierID";
            SupplierID.HeaderText = "Supplier ID";
            SupplierID.Name = "SupplierID";
            SupplierID.Width = 138;
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCancel.Location = new Point(385, 197);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 67;
            btnCancel.Text = "CANCEL";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSearch
            // 
            btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSearch.Location = new Point(304, 196);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 66;
            btnSearch.Text = "SEARCH";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDelete.Location = new Point(223, 196);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 65;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnUpdate.Location = new Point(142, 196);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 64;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnInsert
            // 
            btnInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnInsert.Location = new Point(61, 196);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(75, 23);
            btnInsert.TabIndex = 63;
            btnInsert.Text = "INSERT";
            btnInsert.UseVisualStyleBackColor = true;
            btnInsert.Click += btnInsert_Click;
            // 
            // cbSupplier
            // 
            cbSupplier.FormattingEnabled = true;
            cbSupplier.Location = new Point(496, 97);
            cbSupplier.Name = "cbSupplier";
            cbSupplier.Size = new Size(210, 23);
            cbSupplier.TabIndex = 62;
            // 
            // cbCategory
            // 
            cbCategory.FormattingEnabled = true;
            cbCategory.Location = new Point(496, 51);
            cbCategory.Name = "cbCategory";
            cbCategory.Size = new Size(210, 23);
            cbCategory.TabIndex = 61;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(496, 149);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(210, 23);
            txtSearch.TabIndex = 60;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(119, 149);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(210, 23);
            txtQuantity.TabIndex = 59;
            // 
            // txtName
            // 
            txtName.Location = new Point(119, 97);
            txtName.Name = "txtName";
            txtName.Size = new Size(210, 23);
            txtName.TabIndex = 58;
            // 
            // txtID
            // 
            txtID.Location = new Point(119, 51);
            txtID.Name = "txtID";
            txtID.Size = new Size(210, 23);
            txtID.TabIndex = 57;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label18.Location = new Point(421, 152);
            label18.Name = "label18";
            label18.Size = new Size(45, 15);
            label18.TabIndex = 56;
            label18.Text = "Search";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label19.Location = new Point(421, 100);
            label19.Name = "label19";
            label19.Size = new Size(69, 15);
            label19.TabIndex = 55;
            label19.Text = "Supplier ID";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label20.Location = new Point(421, 54);
            label20.Name = "label20";
            label20.Size = new Size(73, 15);
            label20.TabIndex = 54;
            label20.Text = "Category ID";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label21.Location = new Point(61, 152);
            label21.Name = "label21";
            label21.Size = new Size(55, 15);
            label21.TabIndex = 53;
            label21.Text = "Quantity";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label22.Location = new Point(61, 100);
            label22.Name = "label22";
            label22.Size = new Size(40, 15);
            label22.TabIndex = 52;
            label22.Text = "Name";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label23.Location = new Point(61, 54);
            label23.Name = "label23";
            label23.Size = new Size(20, 15);
            label23.TabIndex = 51;
            label23.Text = "ID";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label24.Location = new Point(247, 4);
            label24.Name = "label24";
            label24.Size = new Size(243, 25);
            label24.TabIndex = 50;
            label24.Text = "PRODUCT MANAGEMENT";
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(txtUserID);
            tabPage4.Controls.Add(label31);
            tabPage4.Controls.Add(dtpOrderDate);
            tabPage4.Controls.Add(btnOrderCancel);
            tabPage4.Controls.Add(btnOrderSearch);
            tabPage4.Controls.Add(btnOrderDelete);
            tabPage4.Controls.Add(btnOrderUpdate);
            tabPage4.Controls.Add(btnOrderInsert);
            tabPage4.Controls.Add(dgvOrder);
            tabPage4.Controls.Add(label36);
            tabPage4.Controls.Add(label35);
            tabPage4.Controls.Add(txtOrderSearch);
            tabPage4.Controls.Add(txtTotalAmount);
            tabPage4.Controls.Add(txtOrderCustomerID);
            tabPage4.Controls.Add(txtOrderID);
            tabPage4.Controls.Add(label30);
            tabPage4.Controls.Add(label32);
            tabPage4.Controls.Add(label33);
            tabPage4.Controls.Add(label34);
            tabPage4.Controls.Add(label29);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(768, 373);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Manager Order";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // txtUserID
            // 
            txtUserID.Location = new Point(102, 266);
            txtUserID.Name = "txtUserID";
            txtUserID.Size = new Size(200, 23);
            txtUserID.TabIndex = 55;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label31.Location = new Point(18, 269);
            label31.Name = "label31";
            label31.Size = new Size(49, 15);
            label31.TabIndex = 54;
            label31.Text = "User ID";
            // 
            // dtpOrderDate
            // 
            dtpOrderDate.Location = new Point(102, 116);
            dtpOrderDate.Name = "dtpOrderDate";
            dtpOrderDate.Size = new Size(200, 23);
            dtpOrderDate.TabIndex = 53;
            // 
            // btnOrderCancel
            // 
            btnOrderCancel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnOrderCancel.Location = new Point(344, 316);
            btnOrderCancel.Name = "btnOrderCancel";
            btnOrderCancel.Size = new Size(75, 23);
            btnOrderCancel.TabIndex = 52;
            btnOrderCancel.Text = "CANCEL";
            btnOrderCancel.UseVisualStyleBackColor = true;
            btnOrderCancel.Click += btnOrderCancel_Click;
            // 
            // btnOrderSearch
            // 
            btnOrderSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnOrderSearch.Location = new Point(263, 316);
            btnOrderSearch.Name = "btnOrderSearch";
            btnOrderSearch.Size = new Size(75, 23);
            btnOrderSearch.TabIndex = 51;
            btnOrderSearch.Text = "SEARCH";
            btnOrderSearch.UseVisualStyleBackColor = true;
            btnOrderSearch.Click += btnOrderSearch_Click;
            // 
            // btnOrderDelete
            // 
            btnOrderDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnOrderDelete.Location = new Point(182, 316);
            btnOrderDelete.Name = "btnOrderDelete";
            btnOrderDelete.Size = new Size(75, 23);
            btnOrderDelete.TabIndex = 50;
            btnOrderDelete.Text = "DELETE";
            btnOrderDelete.UseVisualStyleBackColor = true;
            btnOrderDelete.Click += btnOrderDelete_Click;
            // 
            // btnOrderUpdate
            // 
            btnOrderUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnOrderUpdate.Location = new Point(101, 316);
            btnOrderUpdate.Name = "btnOrderUpdate";
            btnOrderUpdate.Size = new Size(75, 23);
            btnOrderUpdate.TabIndex = 49;
            btnOrderUpdate.Text = "UPDATE";
            btnOrderUpdate.UseVisualStyleBackColor = true;
            btnOrderUpdate.Click += btnOrderUpdate_Click;
            // 
            // btnOrderInsert
            // 
            btnOrderInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnOrderInsert.Location = new Point(20, 316);
            btnOrderInsert.Name = "btnOrderInsert";
            btnOrderInsert.Size = new Size(75, 23);
            btnOrderInsert.TabIndex = 48;
            btnOrderInsert.Text = "INSERT";
            btnOrderInsert.UseVisualStyleBackColor = true;
            btnOrderInsert.Click += btnOrderInsert_Click;
            // 
            // dgvOrder
            // 
            dgvOrder.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrder.Columns.AddRange(new DataGridViewColumn[] { OrderID, OrderDate, CustomerIDColumn, TotalAmount });
            dgvOrder.Location = new Point(332, 100);
            dgvOrder.Name = "dgvOrder";
            dgvOrder.Size = new Size(430, 189);
            dgvOrder.TabIndex = 47;
            dgvOrder.CellClick += dgvOrder_CellClick;
            dgvOrder.CellContentClick += dgvOrder_CellContentClick;
            // 
            // OrderID
            // 
            OrderID.DataPropertyName = "OrderID";
            OrderID.HeaderText = "ID";
            OrderID.Name = "OrderID";
            // 
            // OrderDate
            // 
            OrderDate.DataPropertyName = "OrderDate";
            OrderDate.HeaderText = "Date";
            OrderDate.Name = "OrderDate";
            // 
            // CustomerIDColumn
            // 
            CustomerIDColumn.DataPropertyName = "CustomerID";
            CustomerIDColumn.HeaderText = "Customer ID";
            CustomerIDColumn.Name = "CustomerIDColumn";
            // 
            // TotalAmount
            // 
            TotalAmount.DataPropertyName = "TotalAmount";
            TotalAmount.HeaderText = "Total Amount";
            TotalAmount.Name = "TotalAmount";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label36.Location = new Point(463, 15);
            label36.Name = "label36";
            label36.Size = new Size(125, 25);
            label36.TabIndex = 46;
            label36.Text = "List Of Order";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label35.Location = new Point(406, 74);
            label35.Name = "label35";
            label35.Size = new Size(95, 15);
            label35.TabIndex = 45;
            label35.Text = "Search by name";
            // 
            // txtOrderSearch
            // 
            txtOrderSearch.Location = new Point(507, 71);
            txtOrderSearch.Name = "txtOrderSearch";
            txtOrderSearch.Size = new Size(188, 23);
            txtOrderSearch.TabIndex = 44;
            // 
            // txtTotalAmount
            // 
            txtTotalAmount.Location = new Point(102, 214);
            txtTotalAmount.Name = "txtTotalAmount";
            txtTotalAmount.Size = new Size(200, 23);
            txtTotalAmount.TabIndex = 43;
            // 
            // txtOrderCustomerID
            // 
            txtOrderCustomerID.Location = new Point(102, 164);
            txtOrderCustomerID.Name = "txtOrderCustomerID";
            txtOrderCustomerID.Size = new Size(200, 23);
            txtOrderCustomerID.TabIndex = 41;
            // 
            // txtOrderID
            // 
            txtOrderID.Location = new Point(102, 71);
            txtOrderID.Name = "txtOrderID";
            txtOrderID.Size = new Size(200, 23);
            txtOrderID.TabIndex = 39;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label30.Location = new Point(18, 217);
            label30.Name = "label30";
            label30.Size = new Size(82, 15);
            label30.TabIndex = 38;
            label30.Text = "Total Amount";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label32.Location = new Point(18, 167);
            label32.Name = "label32";
            label32.Size = new Size(77, 15);
            label32.TabIndex = 36;
            label32.Text = "Customer ID";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label33.Location = new Point(18, 122);
            label33.Name = "label33";
            label33.Size = new Size(34, 15);
            label33.TabIndex = 35;
            label33.Text = "Date";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label34.Location = new Point(18, 74);
            label34.Name = "label34";
            label34.Size = new Size(20, 15);
            label34.TabIndex = 34;
            label34.Text = "ID";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label29.Location = new Point(36, 15);
            label29.Name = "label29";
            label29.Size = new Size(216, 25);
            label29.TabIndex = 24;
            label29.Text = "ORDER MANAGEMENT";
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(btnStatsEmployee);
            tabPage5.Controls.Add(dtpToDate);
            tabPage5.Controls.Add(dtpFromDate);
            tabPage5.Controls.Add(label25);
            tabPage5.Controls.Add(label26);
            tabPage5.Controls.Add(btnStatsDateRange);
            tabPage5.Controls.Add(btnStatsCustomer);
            tabPage5.Controls.Add(label27);
            tabPage5.Controls.Add(dgvStats);
            tabPage5.Controls.Add(label28);
            tabPage5.Location = new Point(4, 24);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(768, 373);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Statistic";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnStatsEmployee
            // 
            btnStatsEmployee.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnStatsEmployee.Location = new Point(250, 80);
            btnStatsEmployee.Name = "btnStatsEmployee";
            btnStatsEmployee.Size = new Size(75, 61);
            btnStatsEmployee.TabIndex = 18;
            btnStatsEmployee.Text = "By Employee";
            btnStatsEmployee.UseVisualStyleBackColor = true;
            btnStatsEmployee.Click += btnStatsEmployee_Click;
            // 
            // dtpToDate
            // 
            dtpToDate.Location = new Point(486, 120);
            dtpToDate.Name = "dtpToDate";
            dtpToDate.Size = new Size(200, 23);
            dtpToDate.TabIndex = 17;
            // 
            // dtpFromDate
            // 
            dtpFromDate.Location = new Point(486, 80);
            dtpFromDate.Name = "dtpFromDate";
            dtpFromDate.Size = new Size(200, 23);
            dtpFromDate.TabIndex = 16;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(436, 126);
            label25.Name = "label25";
            label25.Size = new Size(23, 15);
            label25.TabIndex = 15;
            label25.Text = "To:";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(436, 84);
            label26.Name = "label26";
            label26.Size = new Size(38, 15);
            label26.TabIndex = 14;
            label26.Text = "From:";
            // 
            // btnStatsDateRange
            // 
            btnStatsDateRange.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnStatsDateRange.Location = new Point(331, 80);
            btnStatsDateRange.Name = "btnStatsDateRange";
            btnStatsDateRange.Size = new Size(75, 61);
            btnStatsDateRange.TabIndex = 13;
            btnStatsDateRange.Text = "By Date Range";
            btnStatsDateRange.UseVisualStyleBackColor = true;
            btnStatsDateRange.Click += btnStatsDateRange_Click;
            // 
            // btnStatsCustomer
            // 
            btnStatsCustomer.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnStatsCustomer.Location = new Point(169, 80);
            btnStatsCustomer.Name = "btnStatsCustomer";
            btnStatsCustomer.Size = new Size(75, 61);
            btnStatsCustomer.TabIndex = 12;
            btnStatsCustomer.Text = "By Customer";
            btnStatsCustomer.UseVisualStyleBackColor = true;
            btnStatsCustomer.Click += btnStatsCustomer_Click;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label27.Location = new Point(45, 95);
            label27.Name = "label27";
            label27.Size = new Size(85, 25);
            label27.TabIndex = 11;
            label27.Text = "SEARCH";
            // 
            // dgvStats
            // 
            dgvStats.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStats.Location = new Point(6, 163);
            dgvStats.Name = "dgvStats";
            dgvStats.Size = new Size(756, 204);
            dgvStats.TabIndex = 10;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label28.Location = new Point(331, 21);
            label28.Name = "label28";
            label28.Size = new Size(102, 25);
            label28.TabIndex = 9;
            label28.Text = "STATISTIC";
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnLogout.Location = new Point(709, 13);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(75, 23);
            btnLogout.TabIndex = 2;
            btnLogout.Text = "LOGOUT";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // Admin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLogout);
            Controls.Add(tabControl1);
            Controls.Add(lbUser);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Admin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin";
            Load += Admin_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEmployee).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrderHistory).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomer).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).EndInit();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrder).EndInit();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStats).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbUser;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private Button btnLogout;
        private Label label9;
        private DataGridView dgvOrderHistory;
        private DataGridView dgvCustomer;
        private DataGridViewTextBoxColumn CustomerID;
        private DataGridViewTextBoxColumn CustomerName;
        private DataGridViewTextBoxColumn PhoneNumber;
        private DataGridViewTextBoxColumn Address;
        private DataGridViewTextBoxColumn Email;
        private Label label8;
        private Button btnCustSearch;
        private Button btnCustDelete;
        private Button btnCustUpdate;
        private Button btnCustInsert;
        private Label label7;
        private TextBox txtCustSearch;
        private TextBox txtCustEmail;
        private TextBox txtCustAddress;
        private TextBox txtCustPhone;
        private TextBox txtCustName;
        private TextBox txtCustID;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label10;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label15;
        private TextBox txtDepartment;
        private TextBox txtAuthorityLevel;
        private TextBox txtPosition;
        private TextBox txtEmpName;
        private TextBox txtEmpID;
        private Label label17;
        private Label label16;
        private TextBox txtEmpSearch;
        private DataGridView dgvEmployee;
        private DataGridViewTextBoxColumn EmployeeID;
        private DataGridViewTextBoxColumn EmployeeName;
        private DataGridViewTextBoxColumn Position;
        private DataGridViewTextBoxColumn AuthorityLevel;
        private DataGridViewTextBoxColumn Department;
        private Button btnEmpInsert;
        private Button btnEmpSearch;
        private Button btnEmpDelete;
        private Button btnEmpUpdate;
        private Label lbQuantityError;
        private Label lbNameError;
        private Label lblDError;
        private DataGridView dgvProduct;
        private DataGridViewTextBoxColumn ProductID;
        private DataGridViewTextBoxColumn ProductName;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn CategoryID;
        private DataGridViewTextBoxColumn SupplierID;
        private Button btnCancel;
        private Button btnSearch;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnInsert;
        private ComboBox cbSupplier;
        private ComboBox cbCategory;
        private TextBox txtSearch;
        private TextBox txtQuantity;
        private TextBox txtName;
        private TextBox txtID;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private DateTimePicker dtpToDate;
        private DateTimePicker dtpFromDate;
        private Label label25;
        private Label label26;
        private Button btnStatsDateRange;
        private Button btnStatsCustomer;
        private Label label27;
        private DataGridView dgvStats;
        private Label label28;
        private Button btnStatsEmployee;
        private TextBox txtTotalAmount;
        private TextBox txtOrderCustomerID;
        private TextBox txtOrderID;
        private Label label30;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label29;
        private Label label36;
        private Label label35;
        private TextBox txtOrderSearch;
        private DataGridView dgvOrder;
        private Button btnOrderCancel;
        private Button btnOrderSearch;
        private Button btnOrderDelete;
        private Button btnOrderUpdate;
        private Button btnOrderInsert;
        private DateTimePicker dtpOrderDate;
        private Button btnEmpCancel;
        private TextBox txtUserID;
        private Label label31;
        private DataGridViewTextBoxColumn OrderID;
        private DataGridViewTextBoxColumn OrderDate;
        private DataGridViewTextBoxColumn CustomerIDColumn;
        private DataGridViewTextBoxColumn TotalAmount;
    }
}