﻿namespace StoreX_Management
{
    partial class Sales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sales));
            lbUser = new Label();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            btnCustCancel = new Button();
            label9 = new Label();
            dgvOrderHistory = new DataGridView();
            dgvCustomer = new DataGridView();
            CustomerID = new DataGridViewTextBoxColumn();
            CustomerName = new DataGridViewTextBoxColumn();
            PhoneNumber = new DataGridViewTextBoxColumn();
            Address = new DataGridViewTextBoxColumn();
            Email = new DataGridViewTextBoxColumn();
            label8 = new Label();
            btnCustSearch = new Button();
            btnCustDelete = new Button();
            btnCustUpdate = new Button();
            btnCustInsert = new Button();
            label7 = new Label();
            txtCustSearch = new TextBox();
            txtCustEmail = new TextBox();
            txtCustAddress = new TextBox();
            txtCustPhone = new TextBox();
            txtCustName = new TextBox();
            txtCustID = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tabPage2 = new TabPage();
            lbQuantityError = new Label();
            lbNameError = new Label();
            lblDError = new Label();
            dgvProduct = new DataGridView();
            ProductID = new DataGridViewTextBoxColumn();
            ProductName = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            CategoryID = new DataGridViewTextBoxColumn();
            SupplierID = new DataGridViewTextBoxColumn();
            btnCancel = new Button();
            btnSearch = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnInsert = new Button();
            cbSupplier = new ComboBox();
            cbCategory = new ComboBox();
            txtSearch = new TextBox();
            txtQuantity = new TextBox();
            txtName = new TextBox();
            txtID = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            tabPage3 = new TabPage();
            btnSubmitOrder = new Button();
            dtpOrderDate = new DateTimePicker();
            txtOrderAmount = new TextBox();
            txtOrderCustomer = new TextBox();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            tabPage4 = new TabPage();
            dtpToDate = new DateTimePicker();
            dtpFromDate = new DateTimePicker();
            label24 = new Label();
            label23 = new Label();
            btnStatsDateRange = new Button();
            btnStatsCustomer = new Button();
            label22 = new Label();
            dgvStats = new DataGridView();
            label21 = new Label();
            btnLogout = new Button();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrderHistory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomer).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).BeginInit();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStats).BeginInit();
            SuspendLayout();
            // 
            // lbUser
            // 
            lbUser.AutoSize = true;
            lbUser.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbUser.Location = new Point(12, 9);
            lbUser.Name = "lbUser";
            lbUser.Size = new Size(64, 25);
            lbUser.TabIndex = 0;
            lbUser.Text = "USER:";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Location = new Point(12, 37);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(776, 401);
            tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnCustCancel);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(dgvOrderHistory);
            tabPage1.Controls.Add(dgvCustomer);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(btnCustSearch);
            tabPage1.Controls.Add(btnCustDelete);
            tabPage1.Controls.Add(btnCustUpdate);
            tabPage1.Controls.Add(btnCustInsert);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(txtCustSearch);
            tabPage1.Controls.Add(txtCustEmail);
            tabPage1.Controls.Add(txtCustAddress);
            tabPage1.Controls.Add(txtCustPhone);
            tabPage1.Controls.Add(txtCustName);
            tabPage1.Controls.Add(txtCustID);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(768, 373);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Manage Customer";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnCustCancel
            // 
            btnCustCancel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnCustCancel.Location = new Point(180, 312);
            btnCustCancel.Name = "btnCustCancel";
            btnCustCancel.Size = new Size(75, 23);
            btnCustCancel.TabIndex = 22;
            btnCustCancel.Text = "CANCEL";
            btnCustCancel.UseVisualStyleBackColor = true;
            btnCustCancel.Click += btnCustCancel_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label9.Location = new Point(427, 226);
            label9.Name = "label9";
            label9.Size = new Size(239, 25);
            label9.TabIndex = 21;
            label9.Text = "Customer's Order History";
            // 
            // dgvOrderHistory
            // 
            dgvOrderHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrderHistory.Location = new Point(299, 254);
            dgvOrderHistory.Name = "dgvOrderHistory";
            dgvOrderHistory.Size = new Size(463, 110);
            dgvOrderHistory.TabIndex = 20;
            // 
            // dgvCustomer
            // 
            dgvCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomer.Columns.AddRange(new DataGridViewColumn[] { CustomerID, CustomerName, PhoneNumber, Address, Email });
            dgvCustomer.Location = new Point(299, 83);
            dgvCustomer.Name = "dgvCustomer";
            dgvCustomer.Size = new Size(463, 121);
            dgvCustomer.TabIndex = 19;
            dgvCustomer.CellClick += dgvCustomer_CellClick;
            // 
            // CustomerID
            // 
            CustomerID.DataPropertyName = "CustomerID";
            CustomerID.HeaderText = "Customer ID";
            CustomerID.Name = "CustomerID";
            // 
            // CustomerName
            // 
            CustomerName.DataPropertyName = "CustomerName";
            CustomerName.HeaderText = "Name";
            CustomerName.Name = "CustomerName";
            // 
            // PhoneNumber
            // 
            PhoneNumber.DataPropertyName = "PhoneNumber";
            PhoneNumber.HeaderText = "Number";
            PhoneNumber.Name = "PhoneNumber";
            // 
            // Address
            // 
            Address.DataPropertyName = "Address";
            Address.HeaderText = "Address";
            Address.Name = "Address";
            // 
            // Email
            // 
            Email.DataPropertyName = "Email";
            Email.HeaderText = "Email";
            Email.Name = "Email";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label8.Location = new Point(466, 26);
            label8.Name = "label8";
            label8.Size = new Size(159, 25);
            label8.TabIndex = 18;
            label8.Text = "List Of Customer";
            // 
            // btnCustSearch
            // 
            btnCustSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustSearch.Location = new Point(99, 341);
            btnCustSearch.Name = "btnCustSearch";
            btnCustSearch.Size = new Size(75, 23);
            btnCustSearch.TabIndex = 17;
            btnCustSearch.Text = "SEARCH";
            btnCustSearch.UseVisualStyleBackColor = true;
            btnCustSearch.Click += btnCustSearch_Click;
            // 
            // btnCustDelete
            // 
            btnCustDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustDelete.Location = new Point(18, 341);
            btnCustDelete.Name = "btnCustDelete";
            btnCustDelete.Size = new Size(75, 23);
            btnCustDelete.TabIndex = 16;
            btnCustDelete.Text = "DELETE";
            btnCustDelete.UseVisualStyleBackColor = true;
            btnCustDelete.Click += btnCustDelete_Click;
            // 
            // btnCustUpdate
            // 
            btnCustUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustUpdate.Location = new Point(99, 312);
            btnCustUpdate.Name = "btnCustUpdate";
            btnCustUpdate.Size = new Size(75, 23);
            btnCustUpdate.TabIndex = 15;
            btnCustUpdate.Text = "UPDATE";
            btnCustUpdate.UseVisualStyleBackColor = true;
            btnCustUpdate.Click += btnCustUpdate_Click;
            // 
            // btnCustInsert
            // 
            btnCustInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCustInsert.Location = new Point(18, 312);
            btnCustInsert.Name = "btnCustInsert";
            btnCustInsert.Size = new Size(75, 23);
            btnCustInsert.TabIndex = 14;
            btnCustInsert.Text = "INSERT";
            btnCustInsert.UseVisualStyleBackColor = true;
            btnCustInsert.Click += btnCustInsert_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label7.Location = new Point(299, 57);
            label7.Name = "label7";
            label7.Size = new Size(95, 15);
            label7.TabIndex = 12;
            label7.Text = "Search by name";
            // 
            // txtCustSearch
            // 
            txtCustSearch.Location = new Point(400, 54);
            txtCustSearch.Name = "txtCustSearch";
            txtCustSearch.Size = new Size(188, 23);
            txtCustSearch.TabIndex = 11;
            // 
            // txtCustEmail
            // 
            txtCustEmail.Location = new Point(85, 283);
            txtCustEmail.Name = "txtCustEmail";
            txtCustEmail.Size = new Size(188, 23);
            txtCustEmail.TabIndex = 10;
            // 
            // txtCustAddress
            // 
            txtCustAddress.Location = new Point(85, 233);
            txtCustAddress.Name = "txtCustAddress";
            txtCustAddress.Size = new Size(188, 23);
            txtCustAddress.TabIndex = 9;
            // 
            // txtCustPhone
            // 
            txtCustPhone.Location = new Point(85, 181);
            txtCustPhone.Name = "txtCustPhone";
            txtCustPhone.Size = new Size(188, 23);
            txtCustPhone.TabIndex = 8;
            // 
            // txtCustName
            // 
            txtCustName.Location = new Point(85, 136);
            txtCustName.Name = "txtCustName";
            txtCustName.Size = new Size(188, 23);
            txtCustName.TabIndex = 7;
            // 
            // txtCustID
            // 
            txtCustID.Location = new Point(85, 88);
            txtCustID.Name = "txtCustID";
            txtCustID.Size = new Size(188, 23);
            txtCustID.TabIndex = 6;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(22, 286);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 5;
            label6.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(22, 236);
            label5.Name = "label5";
            label5.Size = new Size(51, 15);
            label5.TabIndex = 4;
            label5.Text = "Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(22, 184);
            label4.Name = "label4";
            label4.Size = new Size(53, 15);
            label4.TabIndex = 3;
            label4.Text = "Number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(22, 139);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 2;
            label3.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(22, 91);
            label2.Name = "label2";
            label2.Size = new Size(20, 15);
            label2.TabIndex = 1;
            label2.Text = "ID";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.Location = new Point(37, 26);
            label1.Name = "label1";
            label1.Size = new Size(255, 25);
            label1.TabIndex = 0;
            label1.Text = "CUSTOMER MANAGEMENT";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(lbQuantityError);
            tabPage2.Controls.Add(lbNameError);
            tabPage2.Controls.Add(lblDError);
            tabPage2.Controls.Add(dgvProduct);
            tabPage2.Controls.Add(btnCancel);
            tabPage2.Controls.Add(btnSearch);
            tabPage2.Controls.Add(btnDelete);
            tabPage2.Controls.Add(btnUpdate);
            tabPage2.Controls.Add(btnInsert);
            tabPage2.Controls.Add(cbSupplier);
            tabPage2.Controls.Add(cbCategory);
            tabPage2.Controls.Add(txtSearch);
            tabPage2.Controls.Add(txtQuantity);
            tabPage2.Controls.Add(txtName);
            tabPage2.Controls.Add(txtID);
            tabPage2.Controls.Add(label10);
            tabPage2.Controls.Add(label11);
            tabPage2.Controls.Add(label12);
            tabPage2.Controls.Add(label13);
            tabPage2.Controls.Add(label14);
            tabPage2.Controls.Add(label15);
            tabPage2.Controls.Add(label16);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(768, 373);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Manage Product";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // lbQuantityError
            // 
            lbQuantityError.AutoSize = true;
            lbQuantityError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbQuantityError.ForeColor = Color.Red;
            lbQuantityError.Location = new Point(119, 174);
            lbQuantityError.Name = "lbQuantityError";
            lbQuantityError.Size = new Size(0, 15);
            lbQuantityError.TabIndex = 49;
            // 
            // lbNameError
            // 
            lbNameError.AutoSize = true;
            lbNameError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNameError.ForeColor = Color.Red;
            lbNameError.Location = new Point(119, 122);
            lbNameError.Name = "lbNameError";
            lbNameError.Size = new Size(0, 15);
            lbNameError.TabIndex = 48;
            // 
            // lblDError
            // 
            lblDError.AutoSize = true;
            lblDError.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblDError.ForeColor = Color.Red;
            lblDError.Location = new Point(119, 76);
            lblDError.Name = "lblDError";
            lblDError.Size = new Size(0, 15);
            lblDError.TabIndex = 47;
            // 
            // dgvProduct
            // 
            dgvProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProduct.Columns.AddRange(new DataGridViewColumn[] { ProductID, ProductName, Quantity, CategoryID, SupplierID });
            dgvProduct.Location = new Point(6, 225);
            dgvProduct.Name = "dgvProduct";
            dgvProduct.Size = new Size(756, 142);
            dgvProduct.TabIndex = 46;
            dgvProduct.CellClick += dgvProduct_CellClick;
            // 
            // ProductID
            // 
            ProductID.DataPropertyName = "ProductID";
            ProductID.HeaderText = "Product ID";
            ProductID.Name = "ProductID";
            ProductID.Width = 138;
            // 
            // ProductName
            // 
            ProductName.DataPropertyName = "ProductName";
            ProductName.HeaderText = "Name";
            ProductName.Name = "ProductName";
            ProductName.Width = 138;
            // 
            // Quantity
            // 
            Quantity.DataPropertyName = "Quantity";
            Quantity.HeaderText = "Quantity";
            Quantity.Name = "Quantity";
            Quantity.Width = 138;
            // 
            // CategoryID
            // 
            CategoryID.DataPropertyName = "CategoryID";
            CategoryID.HeaderText = "Category ID";
            CategoryID.Name = "CategoryID";
            CategoryID.Width = 138;
            // 
            // SupplierID
            // 
            SupplierID.DataPropertyName = "SupplierID";
            SupplierID.HeaderText = "Supplier ID";
            SupplierID.Name = "SupplierID";
            SupplierID.Width = 138;
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnCancel.Location = new Point(385, 195);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 44;
            btnCancel.Text = "CANCEL";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSearch
            // 
            btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSearch.Location = new Point(304, 195);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 43;
            btnSearch.Text = "SEARCH";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDelete.Location = new Point(223, 195);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 42;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnUpdate.Location = new Point(142, 195);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 41;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnInsert
            // 
            btnInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnInsert.Location = new Point(61, 195);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(75, 23);
            btnInsert.TabIndex = 40;
            btnInsert.Text = "INSERT";
            btnInsert.UseVisualStyleBackColor = true;
            btnInsert.Click += btnInsert_Click;
            // 
            // cbSupplier
            // 
            cbSupplier.FormattingEnabled = true;
            cbSupplier.Location = new Point(496, 96);
            cbSupplier.Name = "cbSupplier";
            cbSupplier.Size = new Size(210, 23);
            cbSupplier.TabIndex = 39;
            // 
            // cbCategory
            // 
            cbCategory.FormattingEnabled = true;
            cbCategory.Location = new Point(496, 50);
            cbCategory.Name = "cbCategory";
            cbCategory.Size = new Size(210, 23);
            cbCategory.TabIndex = 38;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(496, 148);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(210, 23);
            txtSearch.TabIndex = 37;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(119, 148);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(210, 23);
            txtQuantity.TabIndex = 36;
            // 
            // txtName
            // 
            txtName.Location = new Point(119, 96);
            txtName.Name = "txtName";
            txtName.Size = new Size(210, 23);
            txtName.TabIndex = 35;
            // 
            // txtID
            // 
            txtID.Location = new Point(119, 50);
            txtID.Name = "txtID";
            txtID.Size = new Size(210, 23);
            txtID.TabIndex = 34;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label10.Location = new Point(421, 151);
            label10.Name = "label10";
            label10.Size = new Size(45, 15);
            label10.TabIndex = 33;
            label10.Text = "Search";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label11.Location = new Point(421, 99);
            label11.Name = "label11";
            label11.Size = new Size(69, 15);
            label11.TabIndex = 32;
            label11.Text = "Supplier ID";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label12.Location = new Point(421, 53);
            label12.Name = "label12";
            label12.Size = new Size(73, 15);
            label12.TabIndex = 31;
            label12.Text = "Category ID";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label13.Location = new Point(61, 151);
            label13.Name = "label13";
            label13.Size = new Size(55, 15);
            label13.TabIndex = 30;
            label13.Text = "Quantity";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label14.Location = new Point(61, 99);
            label14.Name = "label14";
            label14.Size = new Size(40, 15);
            label14.TabIndex = 29;
            label14.Text = "Name";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label15.Location = new Point(61, 53);
            label15.Name = "label15";
            label15.Size = new Size(20, 15);
            label15.TabIndex = 28;
            label15.Text = "ID";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label16.Location = new Point(247, 3);
            label16.Name = "label16";
            label16.Size = new Size(243, 25);
            label16.TabIndex = 27;
            label16.Text = "PRODUCT MANAGEMENT";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(btnSubmitOrder);
            tabPage3.Controls.Add(dtpOrderDate);
            tabPage3.Controls.Add(txtOrderAmount);
            tabPage3.Controls.Add(txtOrderCustomer);
            tabPage3.Controls.Add(label20);
            tabPage3.Controls.Add(label19);
            tabPage3.Controls.Add(label18);
            tabPage3.Controls.Add(label17);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(768, 373);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Make Order";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnSubmitOrder
            // 
            btnSubmitOrder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSubmitOrder.Location = new Point(329, 294);
            btnSubmitOrder.Name = "btnSubmitOrder";
            btnSubmitOrder.Size = new Size(127, 49);
            btnSubmitOrder.TabIndex = 7;
            btnSubmitOrder.Text = "SUBMIT ORDER";
            btnSubmitOrder.UseVisualStyleBackColor = true;
            btnSubmitOrder.Click += btnSubmitOrder_Click;
            // 
            // dtpOrderDate
            // 
            dtpOrderDate.Location = new Point(329, 177);
            dtpOrderDate.Name = "dtpOrderDate";
            dtpOrderDate.Size = new Size(223, 23);
            dtpOrderDate.TabIndex = 6;
            // 
            // txtOrderAmount
            // 
            txtOrderAmount.Location = new Point(329, 238);
            txtOrderAmount.Name = "txtOrderAmount";
            txtOrderAmount.Size = new Size(223, 23);
            txtOrderAmount.TabIndex = 5;
            // 
            // txtOrderCustomer
            // 
            txtOrderCustomer.Location = new Point(329, 128);
            txtOrderCustomer.Name = "txtOrderCustomer";
            txtOrderCustomer.Size = new Size(223, 23);
            txtOrderCustomer.TabIndex = 4;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label20.Location = new Point(238, 241);
            label20.Name = "label20";
            label20.Size = new Size(82, 15);
            label20.TabIndex = 3;
            label20.Text = "Total Amount";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label19.Location = new Point(238, 183);
            label19.Name = "label19";
            label19.Size = new Size(70, 15);
            label19.TabIndex = 2;
            label19.Text = "Order Date";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label18.Location = new Point(238, 131);
            label18.Name = "label18";
            label18.Size = new Size(77, 15);
            label18.TabIndex = 1;
            label18.Text = "Customer ID";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label17.Location = new Point(329, 57);
            label17.Name = "label17";
            label17.Size = new Size(146, 25);
            label17.TabIndex = 0;
            label17.Text = "CREATE ORDER";
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(dtpToDate);
            tabPage4.Controls.Add(dtpFromDate);
            tabPage4.Controls.Add(label24);
            tabPage4.Controls.Add(label23);
            tabPage4.Controls.Add(btnStatsDateRange);
            tabPage4.Controls.Add(btnStatsCustomer);
            tabPage4.Controls.Add(label22);
            tabPage4.Controls.Add(dgvStats);
            tabPage4.Controls.Add(label21);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(768, 373);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Statistic";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // dtpToDate
            // 
            dtpToDate.Location = new Point(486, 120);
            dtpToDate.Name = "dtpToDate";
            dtpToDate.Size = new Size(200, 23);
            dtpToDate.TabIndex = 8;
            // 
            // dtpFromDate
            // 
            dtpFromDate.Location = new Point(486, 80);
            dtpFromDate.Name = "dtpFromDate";
            dtpFromDate.Size = new Size(200, 23);
            dtpFromDate.TabIndex = 7;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(436, 126);
            label24.Name = "label24";
            label24.Size = new Size(23, 15);
            label24.TabIndex = 6;
            label24.Text = "To:";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(436, 84);
            label23.Name = "label23";
            label23.Size = new Size(38, 15);
            label23.TabIndex = 5;
            label23.Text = "From:";
            // 
            // btnStatsDateRange
            // 
            btnStatsDateRange.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnStatsDateRange.Location = new Point(331, 80);
            btnStatsDateRange.Name = "btnStatsDateRange";
            btnStatsDateRange.Size = new Size(75, 61);
            btnStatsDateRange.TabIndex = 4;
            btnStatsDateRange.Text = "By Date Range";
            btnStatsDateRange.UseVisualStyleBackColor = true;
            btnStatsDateRange.Click += btnStatsDateRange_Click;
            // 
            // btnStatsCustomer
            // 
            btnStatsCustomer.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnStatsCustomer.Location = new Point(169, 80);
            btnStatsCustomer.Name = "btnStatsCustomer";
            btnStatsCustomer.Size = new Size(75, 61);
            btnStatsCustomer.TabIndex = 3;
            btnStatsCustomer.Text = "By Customer";
            btnStatsCustomer.UseVisualStyleBackColor = true;
            btnStatsCustomer.Click += btnStatsCustomer_Click;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label22.Location = new Point(45, 95);
            label22.Name = "label22";
            label22.Size = new Size(85, 25);
            label22.TabIndex = 2;
            label22.Text = "SEARCH";
            // 
            // dgvStats
            // 
            dgvStats.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStats.Location = new Point(6, 163);
            dgvStats.Name = "dgvStats";
            dgvStats.Size = new Size(756, 204);
            dgvStats.TabIndex = 1;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label21.Location = new Point(331, 21);
            label21.Name = "label21";
            label21.Size = new Size(102, 25);
            label21.TabIndex = 0;
            label21.Text = "STATISTIC";
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnLogout.Location = new Point(709, 13);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(75, 23);
            btnLogout.TabIndex = 2;
            btnLogout.Text = "LOGOUT";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // Sales
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLogout);
            Controls.Add(tabControl1);
            Controls.Add(lbUser);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Sales";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sales";
            Load += Sales_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrderHistory).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomer).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStats).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbUser;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Button btnLogout;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private Label label1;
        private TextBox txtCustEmail;
        private TextBox txtCustAddress;
        private TextBox txtCustPhone;
        private TextBox txtCustName;
        private TextBox txtCustID;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label7;
        private TextBox txtCustSearch;
        private DataGridView dgvCustomer;
        private Label label8;
        private Button btnCustSearch;
        private Button btnCustDelete;
        private Button btnCustUpdate;
        private Button btnCustInsert;
        private DataGridViewTextBoxColumn CustomerID;
        private DataGridViewTextBoxColumn CustomerName;
        private DataGridViewTextBoxColumn PhoneNumber;
        private DataGridViewTextBoxColumn Address;
        private DataGridViewTextBoxColumn Email;
        private Label label9;
        private DataGridView dgvOrderHistory;
        private Label lbQuantityError;
        private Label lbNameError;
        private Label lblDError;
        private DataGridView dgvProduct;
        private DataGridViewTextBoxColumn ProductID;
        private DataGridViewTextBoxColumn ProductName;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn CategoryID;
        private DataGridViewTextBoxColumn SupplierID;
        private Button btnCancel;
        private Button btnSearch;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnInsert;
        private ComboBox cbSupplier;
        private ComboBox cbCategory;
        private TextBox txtSearch;
        private TextBox txtQuantity;
        private TextBox txtName;
        private TextBox txtID;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private DateTimePicker dtpOrderDate;
        private TextBox txtOrderAmount;
        private TextBox txtOrderCustomer;
        private Label label20;
        private Label label19;
        private Label label18;
        private Button btnSubmitOrder;
        private DateTimePicker dtpToDate;
        private DateTimePicker dtpFromDate;
        private Label label24;
        private Label label23;
        private Button btnStatsDateRange;
        private Button btnStatsCustomer;
        private Label label22;
        private DataGridView dgvStats;
        private Label label21;
        private Button btnCustCancel;
    }
}