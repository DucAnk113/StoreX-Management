﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace StoreX_Management
{
    public partial class Warehouse : Form
    {
        SqlConnection connection;
        public Warehouse(string username)
        {
            InitializeComponent();
            connection = new SqlConnection("Server=DucAnk;Database=StoreX;Integrated Security=true;TrustServerCertificate=True;");
            lbUser.Text = "User: " + username;
        }

        private void Warehouse_Load(object sender, EventArgs e)
        {
            connection.Open();
            GetCategory();
            GetSupplier();
            FillData(); //Product management
        }

        public void FillData()
        {
            string query = "SELECT * FROM Products";
            DataTable tbl = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(query, connection);
            ad.Fill(tbl);
            dgvProduct.DataSource = tbl;
            connection.Close();
        }

        public void GetCategory()
        {
            string query = "select CategoryID, CategoryName from Categories";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
            cbCategory.DataSource = table;
            cbCategory.DisplayMember = "CategoryName";
            cbCategory.ValueMember = "CategoryID";
        }

        public void GetSupplier()
        {
            string query = "select SupplierID, SupplierName from Suppliers";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
            cbSupplier.DataSource = table;
            cbSupplier.DisplayMember = "SupplierName";
            cbSupplier.ValueMember = "SupplierID";
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            {
                int error = 0;
                string id = txtID.Text;
                if (id.Equals(""))
                {
                    error = error + 1;
                    lblDError.Text = "ID can't be blank";
                }
                else
                    lblDError.Text = "";
                string name = txtName.Text;
                if (name.Equals(""))
                {
                    error = error + 1;
                    lbNameError.Text = "Name can't be blank";
                }
                else
                    lbNameError.Text = "";
                string quantity = txtQuantity.Text;
                if (quantity.Equals(""))
                {
                    error = error + 1;
                    lbQuantityError.Text = "Quantity can't be blank";
                }
                else
                {
                    string query = "select * from Products where ProductID = @id";
                    connection.Open();
                    SqlCommand cmdcheck = new SqlCommand(query, connection);
                    cmdcheck.Parameters.Add("@id", SqlDbType.Int);
                    cmdcheck.Parameters["@id"].Value = id;
                    SqlDataReader reader = cmdcheck.ExecuteReader();
                    if (reader.Read())
                    {
                        error++;
                        lblDError.Text = "This ID is existing, please choose another";
                    }
                    else
                    {
                        lbQuantityError.Text = "";
                    }
                    connection.Close();
                }
                string catid = cbCategory.SelectedValue.ToString();
                string supid = cbSupplier.SelectedValue.ToString();

                if (error == 0)
                {
                    connection.Open();
                    SqlCommand cmdSetOn = new SqlCommand("SET IDENTITY_INSERT Products ON", connection);
                    cmdSetOn.ExecuteNonQuery();
                    string insert = "INSERT INTO Products (ProductID, ProductName, Quantity, CategoryID, SupplierID) " +
                                    "VALUES (@id, @name, @quantity, @catid, @supid)";
                    SqlCommand cmd = new SqlCommand(insert, connection);
                    cmd.Parameters.Add("@id", SqlDbType.Int);
                    cmd.Parameters["@id"].Value = id;
                    cmd.Parameters.Add("@name", SqlDbType.VarChar);
                    cmd.Parameters["@name"].Value = name;
                    cmd.Parameters.Add("@quantity", SqlDbType.Int);
                    cmd.Parameters["@quantity"].Value = quantity;
                    cmd.Parameters.Add("@catid", SqlDbType.Int);
                    cmd.Parameters["@catid"].Value = catid;
                    cmd.Parameters.Add("@supid", SqlDbType.Int);
                    cmd.Parameters["@supid"].Value = supid;
                    cmd.ExecuteNonQuery();
                    SqlCommand cmdSetOff = new SqlCommand("SET IDENTITY_INSERT Products OFF", connection);
                    cmdSetOff.ExecuteNonQuery();
                    connection.Close();
                    FillData();
                    MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
            txtQuantity.Text = "";
            cbCategory.Text = "";
            cbSupplier.Text = "";
            lblDError.Text = "";
            lbNameError.Text = "";
            lbQuantityError.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show(this, "Do you want to edit?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                string update = "update Products set ProductName =@name, Quantity = @quantity, CategoryID=@catid, SupplierID=@supid"
               + " where ProductID = @productid";
                connection.Open();
                SqlCommand cmd = new SqlCommand(update, connection);
                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;
                cmd.Parameters.Add("@quantity", SqlDbType.Int);
                cmd.Parameters["@quantity"].Value = txtQuantity.Text;
                cmd.Parameters.Add("@catid", SqlDbType.Int);
                cmd.Parameters["@catid"].Value = int.Parse(cbCategory.SelectedValue.ToString());
                cmd.Parameters.Add("@supid", SqlDbType.Int);
                cmd.Parameters["@supid"].Value = int.Parse(cbSupplier.SelectedValue.ToString());
                cmd.Parameters.Add("@productid", SqlDbType.Int);
                cmd.Parameters["@productid"].Value = txtID.Text;
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    FillData();
                    MessageBox.Show(this, "Updated successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(this, "Update failed", "Result", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                connection.Close();
            }
        }

        private void dgvProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvProduct.Rows[e.RowIndex];
                txtID.Text = row.Cells["ProductID"].Value.ToString();
                txtName.Text = row.Cells["ProductName"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
                cbSupplier.SelectedValue = row.Cells["SupplierID"].Value.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show(this, "Do you want to delete?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                connection.Open();
                string delete = "delete from Products where ProductID = @productid";
                SqlCommand cmd = new SqlCommand(delete, connection);
                cmd.Parameters.Add("@productid", SqlDbType.Int);
                cmd.Parameters["@productid"].Value = txtID.Text;
                cmd.ExecuteNonQuery();
                FillData();
                MessageBox.Show(this, "Deleted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword.Equals(""))
            {
                MessageBox.Show(this, "Please enter a product name to search", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "SELECT * FROM Products WHERE ProductName LIKE @keyword";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@keyword", SqlDbType.VarChar);
                cmd.Parameters["@keyword"].Value = "%" + keyword + "%";
                DataTable tbl = new DataTable();
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                ad.Fill(tbl);
                dgvProduct.DataSource = tbl;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                FileName = "Products.csv"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(new FileStream(saveFileDialog.FileName, FileMode.Create), Encoding.UTF8))
                    {
                        StringBuilder header = new StringBuilder();
                        for (int i = 0; i < dgvProduct.Columns.Count; i++)
                        {
                            header.Append(dgvProduct.Columns[i].HeaderText);
                            if (i < dgvProduct.Columns.Count - 1)
                            {
                                header.Append(",");
                            }
                        }
                        sw.WriteLine(header.ToString());

                        foreach (DataGridViewRow row in dgvProduct.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                StringBuilder line = new StringBuilder();
                                for (int i = 0; i < dgvProduct.Columns.Count; i++)
                                {
                                    string cellValue = row.Cells[i].Value == null ? "" : row.Cells[i].Value.ToString();

                                    if (cellValue.Contains(","))
                                        cellValue = "\"" + cellValue + "\"";

                                    line.Append(cellValue);
                                    if (i < dgvProduct.Columns.Count - 1)
                                    {
                                        line.Append(",");
                                    }
                                }
                                sw.WriteLine(line.ToString());
                            }
                        }
                    }
                    MessageBox.Show("Export Successful!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Export failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login loginForm = new Login();
            loginForm.ShowDialog();
            this.Dispose();
        }
    }
}
