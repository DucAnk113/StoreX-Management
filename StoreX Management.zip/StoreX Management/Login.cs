﻿using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StoreX_Management
{
    public partial class Login : Form
    {
        private SqlConnection connection = new SqlConnection("Server=DucAnk;Database=StoreX;Integrated Security=true;TrustServerCertificate=True;");
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            string query = "select * from Users where Username = @username and PasswordHash = @password";
            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@username", SqlDbType.VarChar);
            cmd.Parameters["@username"].Value = username;
            cmd.Parameters.AddWithValue("@password", SqlDbType.VarChar);
            cmd.Parameters["@password"].Value = password;

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                int roleId = Convert.ToInt32(reader["RoleID"]);

                if (roleId == 1) // Admin
                {
                    MessageBox.Show(this, "Login successfully!", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    this.Hide();
                    Admin a = new Admin(username);
                    a.ShowDialog();
                    this.Dispose();
                }
                else if (roleId == 2) // Sales
                {
                    MessageBox.Show(this, "Login successfully!", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    this.Hide();
                    Sales s = new Sales(username);
                    s.ShowDialog();
                    this.Dispose();
                }
                else if (roleId == 3) // Warehouse
                {
                    MessageBox.Show(this, "Login successfully!", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    this.Hide();
                    Warehouse w = new Warehouse(username);
                    w.ShowDialog();
                    this.Dispose();
                }
                else
                {
                    lblError.Text = "You are not allowed to access";
                }
            }
            else
            {
                lblError.Text = "Wrong username or password";
            }

            connection.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Exit the program?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
