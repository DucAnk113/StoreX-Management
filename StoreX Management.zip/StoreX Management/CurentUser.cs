﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreX_Management
{
    public static class CurrentUser
    {
        // Các thuộc tính tĩnh để lưu thông tin người dùng đang đăng nhập
        public static int Id { get; set; }
        public static string Username { get; set; }
    }
}
