﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StoreX_Management
{
    public partial class Admin : Form
    {
        SqlConnection connection;
        public Admin(string username)
        {
            InitializeComponent();
            connection = new SqlConnection("Server=DucAnk;Database=StoreX;Integrated Security=true;TrustServerCertificate=True;");
            lbUser.Text = "USER: " + username;
        }

        //Logout
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login loginForm = new Login();
            loginForm.ShowDialog();
            this.Dispose();
        }

        //Product managemnet
        private void Admin_Load(object sender, EventArgs e)
        {
            connection.Open();
            GetCategory();
            GetSupplier();
            FillData(); //Product management
            FillEmployeeData(); //Employee management
            LoadCustomers(); //Customer management
            LoadOrders(); //Order management
        }

        public void FillData()
        {
            string query = "SELECT * FROM Products";
            DataTable tbl = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(query, connection);
            ad.Fill(tbl);
            dgvProduct.DataSource = tbl;
            connection.Close();
        }

        public void GetCategory()
        {
            string query = "select CategoryID, CategoryName from Categories";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
            cbCategory.DataSource = table;
            cbCategory.DisplayMember = "CategoryName";
            cbCategory.ValueMember = "CategoryID";
        }

        public void GetSupplier()
        {
            string query = "select SupplierID, SupplierName from Suppliers";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            adapter.Fill(table);
            cbSupplier.DataSource = table;
            cbSupplier.DisplayMember = "SupplierName";
            cbSupplier.ValueMember = "SupplierID";
        }

        private void btnOrderInsert_Click(object sender, EventArgs e)
        {
            // Lấy thông tin người dùng/nhân viên đang đăng nhập
            int currentUserID = CurrentUser.Id;
            int currentEmployeeID = CurrentUser.Id; // Giả sử UserID cũng là EmployeeID

            // Kiểm tra các trường khác...
            if (!int.TryParse(txtOrderCustomerID.Text.Trim(), out int cid))
            {
                MessageBox.Show("Please enter a valid Customer ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // ...

            try
            {
                connection.Open();
                const string insertQuery = @"
            INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, UserID, EmployeeID)
            VALUES (@cid, @date, @amt, @uid, @eid)";

                using (var cmd = new SqlCommand(insertQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@cid", cid);
                    cmd.Parameters.AddWithValue("@date", dtpOrderDate.Value);
                    cmd.Parameters.AddWithValue("@amt", decimal.Parse(txtTotalAmount.Text.Trim()));

                    // --- SỬA LẠI THAM SỐ ---
                    // Sử dụng ID của người dùng đang đăng nhập
                    cmd.Parameters.AddWithValue("@uid", currentUserID);
                    cmd.Parameters.AddWithValue("@eid", currentEmployeeID);

                    cmd.ExecuteNonQuery();
                }

                FillOrderData();
                MessageBox.Show(this, "Order inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error inserting order: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void btnOrderCancel_Click(object sender, EventArgs e)
        {
            ClearOrderFields();
            FillOrderData();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            {
                int error = 0;
                string id = txtID.Text;
                if (id.Equals(""))
                {
                    error = error + 1;
                    lblDError.Text = "ID can't be blank";
                }
                else
                    lblDError.Text = "";
                string name = txtName.Text;
                if (name.Equals(""))
                {
                    error = error + 1;
                    lbNameError.Text = "Name can't be blank";
                }
                else
                    lbNameError.Text = "";
                string quantity = txtQuantity.Text;
                if (quantity.Equals(""))
                {
                    error = error + 1;
                    lbQuantityError.Text = "Quantity can't be blank";
                }
                else
                {
                    string query = "select * from Products where ProductID = @id";
                    connection.Open();
                    SqlCommand cmdcheck = new SqlCommand(query, connection);
                    cmdcheck.Parameters.Add("@id", SqlDbType.Int);
                    cmdcheck.Parameters["@id"].Value = id;
                    SqlDataReader reader = cmdcheck.ExecuteReader();
                    if (reader.Read())
                    {
                        error++;
                        lblDError.Text = "This ID is existing, please choose another";
                    }
                    else
                    {
                        lbQuantityError.Text = "";
                    }
                    connection.Close();
                }
                string catid = cbCategory.SelectedValue.ToString();
                string supid = cbSupplier.SelectedValue.ToString();

                if (error == 0)
                {
                    connection.Open();
                    SqlCommand cmdSetOn = new SqlCommand("SET IDENTITY_INSERT Products ON", connection);
                    cmdSetOn.ExecuteNonQuery();
                    string insert = "INSERT INTO Products (ProductID, ProductName, Quantity, CategoryID, SupplierID) " +
                                    "VALUES (@id, @name, @quantity, @catid, @supid)";
                    SqlCommand cmd = new SqlCommand(insert, connection);
                    cmd.Parameters.Add("@id", SqlDbType.Int);
                    cmd.Parameters["@id"].Value = id;
                    cmd.Parameters.Add("@name", SqlDbType.VarChar);
                    cmd.Parameters["@name"].Value = name;
                    cmd.Parameters.Add("@quantity", SqlDbType.Int);
                    cmd.Parameters["@quantity"].Value = quantity;
                    cmd.Parameters.Add("@catid", SqlDbType.Int);
                    cmd.Parameters["@catid"].Value = catid;
                    cmd.Parameters.Add("@supid", SqlDbType.Int);
                    cmd.Parameters["@supid"].Value = supid;
                    cmd.ExecuteNonQuery();
                    SqlCommand cmdSetOff = new SqlCommand("SET IDENTITY_INSERT Products OFF", connection);
                    cmdSetOff.ExecuteNonQuery();
                    connection.Close();
                    FillData();
                    MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
            txtQuantity.Text = "";
            cbCategory.Text = "";
            cbSupplier.Text = "";
            lblDError.Text = "";
            lbNameError.Text = "";
            lbQuantityError.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show(this, "Do you want to edit?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                string update = "update Products set ProductName =@name, Quantity = @quantity, CategoryID=@catid, SupplierID=@supid"
               + " where ProductID = @productid";
                connection.Open();
                SqlCommand cmd = new SqlCommand(update, connection);
                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;
                cmd.Parameters.Add("@quantity", SqlDbType.Int);
                cmd.Parameters["@quantity"].Value = txtQuantity.Text;
                cmd.Parameters.Add("@catid", SqlDbType.Int);
                cmd.Parameters["@catid"].Value = int.Parse(cbCategory.SelectedValue.ToString());
                cmd.Parameters.Add("@supid", SqlDbType.Int);
                cmd.Parameters["@supid"].Value = int.Parse(cbSupplier.SelectedValue.ToString());
                cmd.Parameters.Add("@productid", SqlDbType.Int);
                cmd.Parameters["@productid"].Value = txtID.Text;
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    FillData();
                    MessageBox.Show(this, "Updated successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(this, "Update failed", "Result", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                connection.Close();
            }
        }

        private void dgvProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvProduct.Rows[e.RowIndex];
                txtID.Text = row.Cells["ProductID"].Value.ToString();
                txtName.Text = row.Cells["ProductName"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
                cbSupplier.SelectedValue = row.Cells["SupplierID"].Value.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show(this, "Do you want to delete?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                connection.Open();
                string delete = "delete from Products where ProductID = @productid";
                SqlCommand cmd = new SqlCommand(delete, connection);
                cmd.Parameters.Add("@productid", SqlDbType.Int);
                cmd.Parameters["@productid"].Value = txtID.Text;
                cmd.ExecuteNonQuery();
                FillData();
                MessageBox.Show(this, "Deleted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword.Equals(""))
            {
                MessageBox.Show(this, "Please enter a product name to search", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "SELECT * FROM Products WHERE ProductName LIKE @keyword";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@keyword", SqlDbType.VarChar);
                cmd.Parameters["@keyword"].Value = "%" + keyword + "%";
                DataTable tbl = new DataTable();
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                ad.Fill(tbl);
                dgvProduct.DataSource = tbl;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        public void LoadEmployees()
        {
            FillEmployeeData();
        }

        public void FillEmployeeData()
        {
            var query = "SELECT * FROM Employees";
            var tbl = new DataTable();
            using (var da = new SqlDataAdapter(query, connection))
            {
                da.Fill(tbl);
            }
            dgvEmployee.DataSource = tbl;
            connection.Close();
        }
        private void ClearEmployeeFields()
        {
            txtEmpID.Text = "";
            txtEmpName.Text = "";
            txtPosition.Text = "";
            txtAuthorityLevel.Text = "";
            txtDepartment.Text = "";
            txtEmpSearch.Text = "";
        }

        private void btnEmpInsert_Click(object sender, EventArgs e)
        {
            int error = 0;
            string name = txtEmpName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                error++;
                MessageBox.Show(this, "Name is required", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            string pos = txtPosition.Text.Trim();
            string auth = txtAuthorityLevel.Text.Trim();
            string dept = txtDepartment.Text.Trim();

            if (error == 0)
            {
                try
                {
                    connection.Open();
                    const string insert = @"
                        INSERT INTO Employees
                            (EmployeeName, Position, AuthorityLevel, Department)
                        VALUES
                            (@name, @pos, @auth, @dept)";
                    using (var cmd = new SqlCommand(insert, connection))
                    {
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@pos", pos);
                        cmd.Parameters.AddWithValue("@auth", auth);
                        cmd.Parameters.AddWithValue("@dept", dept);
                        cmd.ExecuteNonQuery();
                    }
                    FillEmployeeData();
                    MessageBox.Show(this, "Employee added", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void btnEmpUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEmpID.Text)) return;
            if (MessageBox.Show(this, "Save changes?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;
            try
            {
                connection.Open();
                var update = @"
            UPDATE Employees
            SET EmployeeName    = @name,
                Position        = @pos,
                AuthorityLevel  = @auth,
                Department      = @dept
            WHERE EmployeeID    = @id";
                using (var cmd = new SqlCommand(update, connection))
                {
                    cmd.Parameters.AddWithValue("@name", txtEmpName.Text.Trim());
                    cmd.Parameters.AddWithValue("@pos", txtPosition.Text.Trim());
                    cmd.Parameters.AddWithValue("@auth", int.Parse(txtAuthorityLevel.Text.Trim()));
                    cmd.Parameters.AddWithValue("@dept", txtDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", int.Parse(txtEmpID.Text));
                    var rows = cmd.ExecuteNonQuery();
                    MessageBox.Show(this,
                        rows > 0 ? "Updated successfully" : "No record updated",
                        "Result",
                        rows > 0 ? MessageBoxButtons.OK : MessageBoxButtons.OK,
                        rows > 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                }
                ClearEmployeeFields();
                FillEmployeeData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnEmpDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEmpID.Text)) return;
            if (MessageBox.Show(this, "Delete this employee?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;

            try
            {
                connection.Open();
                var delete = "DELETE FROM Employees WHERE EmployeeID = @id";
                using (var cmd = new SqlCommand(delete, connection))
                {
                    cmd.Parameters.AddWithValue("@id", int.Parse(txtEmpID.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show(this, "Deleted", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearEmployeeFields();
                FillEmployeeData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnEmpSearch_Click(object sender, EventArgs e)
        {
            var kw = txtEmpSearch.Text.Trim();
            if (kw == "")
            {
                MessageBox.Show(this, "Enter name to search", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                connection.Open();
                var query = "SELECT * FROM Employees WHERE EmployeeName LIKE @kw";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@kw", "%" + kw + "%");
                    var tbl = new DataTable();
                    using (var da = new SqlDataAdapter(cmd))
                        da.Fill(tbl);
                    dgvEmployee.DataSource = tbl;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        //Customer management
        public void LoadCustomers()
        {
            FillCustomerData();
        }

        public void FillCustomerData()
        {
            const string query = "SELECT * FROM Customers";
            var tbl = new DataTable();
            using (var da = new SqlDataAdapter(query, connection))
                da.Fill(tbl);

            dgvCustomer.DataSource = tbl;
            connection.Close();
        }

        private void ClearCustomerFields()
        {
            txtCustID.Text = "";
            txtCustName.Text = "";
            txtCustEmail.Text = "";
            txtCustPhone.Text = "";
            txtCustAddress.Text = "";
            txtCustSearch.Text = "";
            dgvOrderHistory.DataSource = null;
        }

        private void LoadOrderHistory(int customerId)
        {
            const string query = @"
        SELECT OrderID, OrderDate, TotalAmount
          FROM Orders
         WHERE CustomerID = @cid";
            var tbl = new DataTable();
            using (var cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@cid", customerId);
                using (var da = new SqlDataAdapter(cmd))
                    da.Fill(tbl);
            }
            dgvOrderHistory.DataSource = tbl;
        }

        private void btnCustInsert_Click(object sender, EventArgs e)
        {
            int error = 0;
            string name = txtCustName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                error++;
                MessageBox.Show(this, "Name is required", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            string phone = txtCustPhone.Text.Trim();
            string addr = txtCustAddress.Text.Trim();
            string email = txtCustEmail.Text.Trim();

            if (error == 0)
            {
                try
                {
                    connection.Open();
                    const string insert = @"
                        INSERT INTO Customers
                            (CustomerName, PhoneNumber, Address, Email)
                        VALUES
                            (@name, @phone, @addr, @email)";
                    using (var cmd = new SqlCommand(insert, connection))
                    {
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@phone", phone);
                        cmd.Parameters.AddWithValue("@addr", addr);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.ExecuteNonQuery();
                    }
                    FillCustomerData();
                    MessageBox.Show(this, "Customer added", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void btnCustUpdate_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtCustID.Text, out var id)) return;
            if (MessageBox.Show("Save changes?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;

            try
            {
                connection.Open();
                const string update = @"
            UPDATE Customers
               SET CustomerName = @name,
                   PhoneNumber  = @phone,
                   Address      = @addr,
                   Email        = @email
             WHERE CustomerID  = @id";
                using (var cmd = new SqlCommand(update, connection))
                {
                    cmd.Parameters.AddWithValue("@name", txtCustName.Text.Trim());
                    cmd.Parameters.AddWithValue("@phone", txtCustPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@addr", txtCustAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", txtCustEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", id);
                    var rows = cmd.ExecuteNonQuery();
                    MessageBox.Show(
                        rows > 0 ? "Updated successfully" : "No record updated",
                        "Result",
                        MessageBoxButtons.OK,
                        rows > 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning
                    );
                }
                ClearCustomerFields();
                FillCustomerData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnCustDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtCustID.Text, out var id)) return;
            if (MessageBox.Show("Delete this customer?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;

            try
            {
                connection.Open();
                const string delete = "DELETE FROM Customers WHERE CustomerID = @id";
                using (var cmd = new SqlCommand(delete, connection))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Deleted", "Result",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearCustomerFields();
                FillCustomerData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnCustSearch_Click(object sender, EventArgs e)
        {
            var kw = txtCustSearch.Text.Trim();
            if (kw == "")
            {
                MessageBox.Show("Enter name to search", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                connection.Open();
                const string query = @"
            SELECT * 
              FROM Customers 
             WHERE CustomerName LIKE @kw";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@kw", "%" + kw + "%");
                    var tbl = new DataTable();
                    using (var da = new SqlDataAdapter(cmd))
                        da.Fill(tbl);
                    dgvCustomer.DataSource = tbl;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void dgvCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvCustomer.Rows[e.RowIndex];
            txtCustID.Text = row.Cells["CustomerID"].Value.ToString();
            txtCustName.Text = row.Cells["CustomerName"].Value.ToString();
            txtCustPhone.Text = row.Cells["PhoneNumber"].Value.ToString();
            txtCustAddress.Text = row.Cells["Address"].Value.ToString();
            txtCustEmail.Text = row.Cells["Email"].Value.ToString();

            if (int.TryParse(txtCustID.Text, out var cid))
                LoadOrderHistory(cid);
        }

        public void LoadOrders()
        {
            FillOrderData();
        }

        public void FillOrderData()
        {
            // Sử dụng verbatim string giúp câu lệnh SQL rõ ràng và không bị lỗi thiếu khoảng trắng
            string query = @"
        SELECT 
            o.OrderID,
            o.CustomerID,
            c.CustomerName,
            o.OrderDate,
            o.TotalAmount, 
            o.UserID
        FROM 
            [Orders] o 
        JOIN 
            Customers c ON o.CustomerID = c.CustomerID";
            DataTable tbl = new DataTable();
            SqlDataAdapter ad = new SqlDataAdapter(query, connection);
            ad.Fill(tbl);
            dgvOrder.DataSource = tbl;
            connection.Close();
        }
        private void ClearOrderFields()
        {
            txtOrderID.Text = string.Empty;
            txtOrderCustomerID.Text = string.Empty;
            dtpOrderDate.Value = DateTime.Today;
            txtTotalAmount.Text = string.Empty;
            txtUserID.Text = string.Empty; // Thêm trường UserID
            txtOrderSearch.Text = string.Empty;
        }

        private void btnOrderUpdate_Click(object sender, EventArgs e)
        {
            // Thêm kiểm tra cho UserID
            if (!int.TryParse(txtOrderID.Text, out int oid)) return;
            if (!int.TryParse(txtOrderCustomerID.Text.Trim(), out int cid)) return;
            if (!int.TryParse(txtUserID.Text.Trim(), out int uid)) // --- THÊM KIỂM TRA UserID ---
            {
                MessageBox.Show("Please provide a valid User ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Save changes?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                connection.Open();
                // --- SỬA ĐỔI CÂU LỆNH SQL ---
                // Thêm UserID vào câu lệnh UPDATE
                string update = "UPDATE [Order] SET CustomerID = @cid, OrderDate = @date, TotalAmount = @amt, UserID = @uid WHERE OrderID = @id";
                SqlCommand cmd = new SqlCommand(update, connection);
                cmd.Parameters.AddWithValue("@cid", cid);
                cmd.Parameters.AddWithValue("@date", dtpOrderDate.Value);
                cmd.Parameters.AddWithValue("@amt", decimal.Parse(txtTotalAmount.Text.Trim()));
                cmd.Parameters.AddWithValue("@id", oid);
                // --- THÊM THAM SỐ UserID ---
                cmd.Parameters.AddWithValue("@uid", uid);

                int rows = cmd.ExecuteNonQuery();
                MessageBox.Show(rows > 0 ? "Updated successfully" : "No record updated", "Result", MessageBoxButtons.OK, rows > 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                ClearOrderFields();
                FillOrderData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnOrderDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtOrderID.Text, out int oid)) return;
            if (MessageBox.Show("Delete this order?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                connection.Open();
                string delete = "DELETE FROM Orders WHERE OrderID = @id";
                SqlCommand cmd = new SqlCommand(delete, connection);
                cmd.Parameters.AddWithValue("@id", oid);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearOrderFields();
                FillOrderData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void btnOrderSearch_Click(object sender, EventArgs e)
        {
            string kw = txtOrderSearch.Text.Trim();
            if (kw == string.Empty)
            {
                MessageBox.Show("Enter customer or product name to search", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                connection.Open();
                string query = "SELECT DISTINCT o.OrderID, o.CustomerID, c.CustomerName, o.OrderDate, o.TotalAmount, o.UserID " +
                               "FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID " +
                               "LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID " +
                               "LEFT JOIN Products p ON od.ProductID = p.ProductID " +
                               "WHERE c.CustomerName LIKE @kw OR p.ProductName LIKE @kw";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@kw", "%" + kw + "%");
                DataTable tbl = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(tbl);
                dgvOrder.DataSource = tbl;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open) connection.Close();
            }
        }

        private void dgvOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvOrder.Rows[e.RowIndex];

            try
            {
                // Gán giá trị một cách an toàn
                txtOrderID.Text = row.Cells["OrderID"].Value?.ToString() ?? ""; // Giả sử tên cột là "ID"
                txtOrderCustomerID.Text = row.Cells["CustomerIDColumn"].Value?.ToString() ?? ""; // Giả sử tên cột là "Customer ID"
                txtTotalAmount.Text = row.Cells["TotalAmount"].Value?.ToString() ?? ""; // Cột này có thể không hiển thị nhưng vẫn cần lấy dữ liệu

                // --- THÊM DÒNG NÀY ---
                // Lấy UserID từ hàng được chọn và hiển thị lên TextBox
                txtUserID.Text = row.Cells["UserID"].Value?.ToString() ?? ""; // Giả sử tên cột là "User ID"

                // Chuyển đổi ngày tháng một cách an toàn
                if (row.Cells["OrderDate"].Value != null && DateTime.TryParse(row.Cells["OrderDate"].Value.ToString(), out DateTime orderDate))
                {
                    dtpOrderDate.Value = orderDate;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Statistics
        public void GetOrderStatsByCustomer(DataGridView grid)
        {
            string query = "SELECT c.CustomerName, COUNT(o.OrderID) AS TotalOrders, SUM(o.TotalAmount) AS TotalSpent " +
                           "FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID " +
                           "GROUP BY c.CustomerName ORDER BY TotalSpent DESC";
            DataTable tbl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, connection);
            da.Fill(tbl);
            grid.DataSource = tbl;
        }

        public void GetOrderStatsByEmployee(DataGridView grid)
        {
            // Sử dụng verbatim string để dễ đọc và sửa lỗi
            string query = @"
            SELECT 
            e.EmployeeName, 
            COUNT(o.OrderID) AS TotalOrders, 
            SUM(o.TotalAmount) AS TotalSales
            FROM 
            Orders o -- Thêm bí danh 'o' cho bảng Orders
            JOIN 
            Employees e ON o.OrderID = e.EmployeeID -- <<< SỬA Ở ĐÂY
            GROUP BY 
            e.EmployeeName 
            ORDER BY 
            TotalSales DESC";

            DataTable tbl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(query, connection);

            try
            {
                da.Fill(tbl);
                grid.DataSource = tbl;
            }
            catch (Exception ex)
            {
                // Hiển thị thông báo lỗi chi tiết hơn
                MessageBox.Show("Đã xảy ra lỗi khi truy vấn dữ liệu: \n" + ex.Message, "Lỗi SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void GetOrderStatsByDateRange(DateTime fromDate, DateTime toDate, DataGridView grid)
        {
            string query = "SELECT OrderID, CustomerID, OrderDate, TotalAmount FROM Orders " +
                           "WHERE OrderDate BETWEEN @from AND @to ORDER BY OrderDate";
            DataTable tbl = new DataTable();
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@from", fromDate);
            cmd.Parameters.AddWithValue("@to", toDate);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(tbl);
            grid.DataSource = tbl;
        }

        private void btnStatsCustomer_Click(object sender, EventArgs e)
        {
            GetOrderStatsByCustomer(dgvStats);
        }

        private void btnStatsEmployee_Click(object sender, EventArgs e)
        {
            GetOrderStatsByEmployee(dgvStats);
        }

        private void btnStatsDateRange_Click(object sender, EventArgs e)
        {
            DateTime from = dtpFromDate.Value.Date;
            DateTime to = dtpToDate.Value.Date;
            GetOrderStatsByDateRange(from, to, dgvStats);
        }

        private void dgvCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvEmployee_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Bước 1: Đảm bảo người dùng đã nhấp vào một hàng hợp lệ (không phải hàng tiêu đề).
            if (e.RowIndex < 0)
            {
                return;
            }

            // Bước 2: Lấy thông tin từ hàng đã được chọn.
            DataGridViewRow row = dgvEmployee.Rows[e.RowIndex];

            try
            {
                // Bước 3: Điền thông tin từ các ô trong hàng vào các TextBox tương ứng.
                // Mã này sử dụng phương pháp an toàn để tránh lỗi nếu ô không có dữ liệu (null).

                // Lấy Employee ID -> điền vào TextBox ID
                // Giả sử tên cột trong DataGridView là "EmployeeID"
                txtEmpID.Text = row.Cells["EmployeeID"].Value?.ToString() ?? "";

                // Lấy Name -> điền vào TextBox Name
                // Giả sử tên cột là "Name"
                txtEmpName.Text = row.Cells["EmployeeName"].Value?.ToString() ?? "";

                // Lấy Position -> điền vào TextBox Position
                // Giả sử tên cột là "Position"
                txtPosition.Text = row.Cells["Position"].Value?.ToString() ?? "";

                // Lấy Authority -> điền vào TextBox Authority
                // Giả sử tên cột là "Authority"
                txtAuthorityLevel.Text = row.Cells["AuthorityLevel"].Value?.ToString() ?? "";

                // Lấy Department -> điền vào TextBox Department
                // Cột này không hiển thị trên lưới, nhưng dữ liệu có thể tồn tại nếu bạn đã truy vấn nó.
                // Giả sử tên cột là "Department"
                if (dgvEmployee.Columns.Contains("Department"))
                {
                    txtDepartment.Text = row.Cells["Department"].Value?.ToString() ?? "";
                }
                else
                {
                    txtDepartment.Text = ""; // Xóa trắng nếu không có cột Department
                }
            }
            catch (Exception ex)
            {
                // Hiển thị thông báo nếu có lỗi không mong muốn xảy ra
                MessageBox.Show("Error loading employee data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEmpCancel_Click(object sender, EventArgs e)
        {
            ClearEmployeeFields();
        }

        private void dgvProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvOrder_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCustCancel_Click(object sender, EventArgs e)
        {

        }
    }
}
